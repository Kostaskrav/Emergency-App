// Main CLI function

import arg from 'arg';
import { COMMANDS } from './params';
import { healthCheck } from './calls/health_check'
import { login } from './calls/login'
import { addUser, getUser, deleteUser, listUsers } from './calls/admin_users'
import { searchToken } from './token_manager';

// argument parser uses arg package
function parseArgumentsIntoOptions(rawArgs) {
  try {
    const args = arg(
      {
        '--format': String,
        '-f': '--format',
        '--username': String,
        '-u': '--username',
        '--password': String,
        '-p': '--password',
        '--email': String,
        '-e': '--email',
        '--firstName': String,
        '--lastName': String,
        '-l': '--lastname',
        '--role': String,
        '-r': '--role',
        '--agency': String,
        '-a': '--agency',
        '--age': String,
        '--gender': String,
        '-g': '--gender',
        '--x': String,
        '-x': '--x',
        '--y': String,
        '-y': '--y',
        '--id': String,
        '-i': '--id',
        '--isHead': Boolean
      },
      {
        argv: rawArgs.slice(2),
      }
    );
    return {
      command: args._[0],
      format: args['--format'],
      username: args['--username'],
      password: args['--password'],
      email: args['--email'],
      firstName: args['--firstName'],
      lastName: args['--lastName'],
      role: args['--role'],
      agency: args['--agency'],
      id: args['--id'],
      x: args['--x'],
      y: args['--y'],
      isHead: args['--isHead'],
      age: args['--age'],
      gender: args['--gender']
    };
  } catch(err) {
    console.log("One of your options is wrong!",err.message);
    process.exit(1);
  }
}

async function authenticateAdmin() {
  let flag = await searchToken();
  if (flag === true) {
    console.log("Welcome!");
  }else if (flag === false) {
    console.log("No token file was found. Please make sure you are logged in.");
    process.exit(3);
  }else {
    process.exit(4);
  }
}
//function to orchistrate command with params
async function callCommand(options) {
  if (!options.command) {
    console.log("No command was given.\nExample use: control-center COMMAND --option1 value1 --option2 value2 ...--optionN valueN");
    process.exit(1);
  }

  switch (options.command) {
    case COMMANDS[0]:
      // health-check
      // Check vars
      if (!options.format) {
        console.log("Format option is missing.\nUse control-center health-check [--format | -f] value");
        process.exit(1);
      }
      if (options.format !== 'json' && options.format !== 'xml') {
        console.log("Format values must either one of: ['json', 'xml']");
        process.exit(1);
      }
      return await healthCheck(options.format);
    case COMMANDS[1]:
      // login
      let flag = 0;
      if (!options.format) {
        console.log("Format option is missing.\nUse control-center login [--format | -f] value");
        flag = 1;
      }
      if (options.format !== 'json' && options.format !== 'xml') {
        console.log("Format values must either one of: ['json', 'xml']");
        process.exit(1);
      }
      if (!options.username) {
        console.log("No username given.\nUse control-center login [--username | -u] value");
        flag = 1;
      }
      if (!options.password) {
        console.log("No password given.\nUse control-center login [--password | -p] value");
        flag = 1;
      }
      if (flag == 1) {
        process.exit(1);
      }
      return await login(options.format, options.username, options.password);
    case COMMANDS[2]:
      // list-users
      if (!options.format) {
        console.log("Format option is missing.\nUse control-center list-users [--format | -f] value");
        process.exit(1);
      }
      if (options.format !== 'json' && options.format !== 'xml') {
        console.log("Format values must either one of: ['json', 'xml']");
        process.exit(1);
      }
      // check if user loged in
      await authenticateAdmin();
      return listUsers(options.format);
    case COMMANDS[3]:
      // add-user
      if (!options.format) {
        console.log("Format option is missing.\nUse control-center add-user [--format | -f] value");
        process.exit(1);
      }
      if (options.format !== 'json' && options.format !== 'xml') {
        console.log("Format values must either one of: ['json', 'xml']");
        process.exit(1);
      }

      if (!options.username) {
        console.log("No username given.\nUse control-center add-user [--username | -u] value");
        process.exit(1);
      }
      if (!options.password) {
        console.log("No password given.\nUse control-center add-user [--password | -p] value");
        process.exit(1);
      }
      if (!options.email) {
        console.log("No email given.\nUse control-center add-user [--email | -e] value");
        process.exit(1);
      }

      // check if user loged in
      await authenticateAdmin();
      return addUser(options.format, options.username, options.password, options.firstName, options.lastName, options.email, options.agency, options.role, options.gender, options.age, options.x, options.y, options.isHead);
    case COMMANDS[4]:
      // get-user
      if (!options.format) {
        console.log("Format option is missing.\nUse control-center get-users [--format | -f] value [--id | -id] value");
        process.exit(1);
      }
      if (options.format !== 'json' && options.format !== 'xml') {
        console.log("Format values must either one of: ['json', 'xml']");
        process.exit(1);
      }
      if (!options.id) {
        console.log("Format option is missing.\nUse control-center delete-users value [--id | -i] value");
        process.exit(1);
      }
      
      // check if user loged in
      await authenticateAdmin();
      return getUser(options.format, options.id);
    case COMMANDS[5]:
      // update-user
      if (!options.format) {
        console.log("Format option is missing.\nUse control-center update-users [--format | -f]");
        process.exit(1);
      }
      if (options.format !== 'json' && options.format !== 'xml') {
        console.log("Format values must either one of: ['json', 'xml']");
        process.exit(1);
      }
      // check if user loged in
      await authenticateAdmin();
      return updateUser(options.format, options.id);
    case COMMANDS[6]:
      // delete-user
      if (!options.format) {
        console.log("Format option is missing.\nUse control-center delete-users [--format | -f] value");
        process.exit(1);
      }
      if (options.format !== 'json' && options.format !== 'xml') {
        console.log("Format values must either one of: ['json', 'xml']");
        process.exit(1);
      }

      if (!options.id) {
        console.log("Format option is missing.\nUse control-center delete-users value [--id | -i] value");
        process.exit(1);
      }
      
      // check if user loged in
      await authenticateAdmin();
      return deleteUser(options.format, options.id);
    default:
      console.log("Command %s not supported.\nValid Commands: ", options.command, COMMANDS);
      process.exit(2);
  }
}

export async function cli(args) {
  let options = parseArgumentsIntoOptions(args);
  let result = await callCommand(options);
  console.log(result);
}