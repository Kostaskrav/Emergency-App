// functions to search and save the token

import { callbackify } from 'util';

const fs = require('fs');

const TOKEN_FILE = 'user_login_token.txt'

export function saveToken(token) {
    fs.writeFile(TOKEN_FILE, token, function(err) {
        if(err) {
            return console.log(err);
        }
        console.log("Token writen in file %s", TOKEN_FILE);
    });
}

export function searchToken() {
    try {
        if (fs.existsSync(TOKEN_FILE)) {
            return true;
        } else {
            return false;
        }
    } catch (err) {
        console.error(err);
        return err;
    }
}

export function getToken() {
    try {
        if (fs.existsSync(TOKEN_FILE)) {
            var contents = fs.readFileSync(TOKEN_FILE, 'utf8');
            return contents.replace(/\s/g, "");
        }
    } catch (err) {
        console.error(err);
        return err;
    }
}