// This file contains the valid parameters for each command
export const COMMANDS = [
    'health-check', 'login', 'list-users', 'add-user',
    'get-user', 'update-user', 'delete-user'
]
export const healthCheck = ['--format']

export const login = ['--format', '--username', '--password']

export const listUser = ['--format', '--start', '--count']

export const addUser = ['--format', '--username','--password','--firstName','--lastName','--role','--agency']

export const getUser = ['--format', '--username','--password','--firstName','--lastName','--role','--agency']

export const updateUser = ['--format', '--id']

export const deleteUser = ['--format', '--id']