// Call to api/health-check

const axios = require('axios');

export async function healthCheck(format) {
    //console.log(format);

    // Make the call GET /health-check
    try {
        const config = {
            method: 'get',
            url: "http://localhost:3001/control-center/api/health-check",
            headers: { }
        };
        if (format === 'json') {
            config.headers['Content-Type'] = 'application/json';
        } else {
            config.headers['Content-Type'] = 'text/xml';
        }

        const res = await axios(config);
        //console.log(res.data);
        if (format === 'json') {
            return res.data.status;
        } else {
            return res.data;
        }
    } catch (err) {
        console.log(err.message);
        process.exit(11);
    }
}