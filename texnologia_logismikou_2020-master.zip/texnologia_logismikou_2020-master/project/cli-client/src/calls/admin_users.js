// Calls to api/admin/users

const axios = require('axios');
import { getToken } from '../token_manager';

export async function listUsers(format) {
    //console.log(format);

    //get the token
    var token = await getToken();
    //console.log(token);
    const config = {
        method: 'get',
        url: "http://localhost:3001/control-center/api/admin/users",
        headers: { 'Authorization': `Bearer ${token}` }
    };

    if (format === 'json') {
        config.headers['Content-Type'] = 'application/json';
    } else {
        config.headers['Content-Type'] = 'text/xml';
    }
    // Make the call GET /admin/users
    try {
        const res = await axios(config);
        return res.data;
    } catch (err) {
        console.log(err.message);
        process.exit(11);
    }
}

export async function addUser(format, username, password, firstName, lastName, email, agency, role, gender, age, x, y, isHead) {
    //console.log(format, username, password, firstName, lastName, email, agency, role, gender, age, x, y, isHead);

    //get the token
    var token = await getToken();

    if (x && y) {
        try {
            const res = await axios.post('http://localhost:3001/control-center/api/admin/users', {
                username: username,
                password: password,
                firstName: firstName,
                lastName: lastName,
                email: email,
                agency: agency,
                role: role,
                gender: gender,
                age: age,
                x: x,
                y: y,
                isAvailable: true,
                isHeadOfAgency: isHead
            }, {
                headers: { 
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });
            return res.data;
        } catch (err) {
            console.log(err.message);
            process.exit(11);
        }
    } else {
        try {
            const res = await axios.post('http://localhost:3001/control-center/api/admin/users', {
                username: username,
                password: password,
                firstName: firstName,
                lastName: lastName,
                email: email,
                agency: agency,
                role: role,
                gender: gender,
                age: age,
                isHeadOfAgency: isHead
            }, {
                headers: { 
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });
            return res.data;
        } catch (err) {
            console.log(err.message);
            process.exit(11);
        }
    }
}

export async function getUser(format, id, username, password, firstName, lastName, role, agency) {
    //console.log(format, id, username, password, firstName, lastName, role, agency);
    
    // Make the call GET /admin/users/{id}
    var token = await getToken();
    //console.log(token);
    const config = {
        method: 'get',
        url: `http://localhost:3001/control-center/api/admin/users/${id}`,
        headers: { 'Authorization': `Bearer ${token}` }
    };

    if (format === 'json') {
        config.headers['Content-Type'] = 'application/json';
    } else {
        config.headers['Content-Type'] = 'text/xml';
    }
    // Make the call GET /admin/users
    try {
        const res = await axios(config);
        return res.data;
    } catch (err) {
        console.log(err.message);
        process.exit(11);
    }
}

export async function deleteUser(format, id) {
    //console.log(format, id);
    
    // Make the call DELETE /admin/users/{id}
    //get the token
    var token = await getToken();
    //console.log(token);
    const config = {
        method: 'delete',
        url: `http://localhost:3001/control-center/api/admin/users/${id}`,
        headers: { 'Authorization': `Bearer ${token}` }
    };

    if (format === 'json') {
        config.headers['Content-Type'] = 'application/json';
    } else {
        config.headers['Content-Type'] = 'text/xml';
    }
    // Make the call GET /admin/users
    try {
        const res = await axios(config);
        return res.data;
    } catch (err) {
        console.log(err.message);
        process.exit(11);
    }
}