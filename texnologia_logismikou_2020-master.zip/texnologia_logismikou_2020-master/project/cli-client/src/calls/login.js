// Calls to api/login

const axios = require('axios');
import { saveToken } from '../token_manager';

export async function login(format, username, password) {
    //console.log(format, username, password);
    // Make the call POST /login
    try {
        const res = await axios.post('http://localhost:3001/control-center/api/login', { 
            username: username,
            password: password
        }, {
            headers: { 
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });

        // ***IMPORTANT*** 
        // Save the token to specified file
        saveToken(res.data.token);
        return (`Welcome ${username}!`);
    } catch (err){
        console.log(err);
        //console.log(err);
        process.exit(10);
    }
}