import React from 'react';
import './syntonisths_forma.css';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';

import ButtonGroup from '@material-ui/core/ButtonGroup';
import Button from '@material-ui/core/Button';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import InputAdornment from '@material-ui/core/InputAdornment';
import PhoneIcon from '@material-ui/icons/Phone';
import PropTypes from 'prop-types';

import WhatshotIcon from '@material-ui/icons/Whatshot';
import LocalHospitalIcon from '@material-ui/icons/LocalHospital';
import DirectionsBoatIcon from '@material-ui/icons/DirectionsBoat';
import SecurityIcon from '@material-ui/icons/Security';

import CloseIcon from '@material-ui/icons/Close';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';

import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';


import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import { ListItemText, ListSubheader } from '@material-ui/core';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import Collapse from '@material-ui/core/Collapse';

/////////////////////////////////////////////////
import PolicyRoundedIcon from '@material-ui/icons/PolicyRounded';
import { withStyles } from '@material-ui/styles';
import SearchIcon from '@material-ui/icons/Search';
import AccountCircleSharpIcon from '@material-ui/icons/AccountCircleSharp';
import HelpRoundedIcon from '@material-ui/icons/HelpRounded';
import { Link } from 'react-router-dom';

/////////////////////////////////////////////////

/////

import { useLocation } from 'react-router-dom';

/////

const locations=['Σπίτι Μήτσιου'];

function TabPanel(props) {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box p={3}>
            <Typography component={'div'}>{children}</Typography>
          </Box>
        )}
      </div>
    );
}
  
TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
    value9: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

function a12yProps(index) {
    return {
      id: `vertical-tab-${index}`,
      'aria-controls': `vertical-tabpanel-${index}`,
    };
}


const MyStyles = makeStyles ({
    tabsStyle : {
        fontSize:"120%",
        height:"120%",
        width:"120%",
        fontStyle:"italic",
        fontWeight:"bold",
    },
    boxesStyle : {
        [`& fieldset`]: {
            borderRadius: 20,
          },
    }
});

// Gia prosthkh h afairesh atomwn se ena peristatiko
// function SimpleDialog2(props) {

//     const [open2 , setOpen2] = React.useState(false);

//     const handleClickOpen2 = () => {
//         setOpen2(true);
//     };

//     const handleClose2 = () => {
//         setOpen2(false);
//     }

// }



// Gia thn allagh topothesias
function SimpleDialog(props) {

    const classes = MyStyles();
    const { onClose, selectedValue, open,pvalue,important,moreimp } = props;

    // console.log("Skata"+pvalue);
  
    const handleClose = () => {
      onClose(selectedValue);
    };
  
    // const handleListItemClick = (value) => {
    //   onClose(value);
    // };

    const [temp2 , setTemp2] = React.useState("");

    const handleTemp2 = (event) => {
        setTemp2(event.target.value);
    }

    const SpecialhandleClose6 = (event,thevalue) => {
        // console.log("The value is:"+thevalue);
        // console.log("Temp2 is :"+temp2);
        // // console.log("Important position is :"+important.position);
        event.preventDefault();
        var joined=important;
        joined[thevalue].position=temp2;
        moreimp(joined);
        onClose(selectedValue);
    }

    return (
        <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open}>
            <DialogTitle id="simple-dialog-title">Αλλαγή τρέχουσας τοποθεσίας</DialogTitle>
            
                
                 {/* <ListItem onClick={() => handleListItemClick(props.position)}> */}
                    <List>
                        <ListItem>
                            <TextField className={classes.margin}
                                id="input-with-icon-textfield"
                                label="Παλιά Τοποθεσία"
                                defaultValue={props.position}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <LocationOnIcon></LocationOnIcon>
                                        </InputAdornment>
                                    ),
                                    readOnly : true,
                                }}
                            >
                            </TextField>
                        </ListItem>
                        <ListItem>
                            <TextField className={classes.margin}
                                id="input-with-icon-textfield"
                                label="Νέα Τοποθεσία"
                                value={temp2}
                                onChange={handleTemp2}
                                InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <LocationOnIcon></LocationOnIcon>
                                    </InputAdornment>
                                ),
                                }}
                            >
                            </TextField> 
                        </ListItem>
                    </List>
                {/* </ListItem> */}
            <DialogActions>
                <Button onClick={handleClose} color="primary">
                    Ακύρωση
                </Button>
                <Button onClick={(event) => {SpecialhandleClose6(event,pvalue)}} color="primary">
                    Επιβεβαίωση Αλλαγής
                </Button>
            </DialogActions>       
        </Dialog>
    );
}

SimpleDialog.propTypes = {
    onClose: PropTypes.func.isRequired,
    open: PropTypes.bool.isRequired,
    selectedValue: PropTypes.string.isRequired,
};


export default function Syntonisths_Form() {
    // const [value, setValue] = React.useState(0);
    // const location = useLocation();
    // console.log(location.state.detail);


    const handleChange = (event, newValue) => {
       
      setValue(newValue);
    };

    const [list_of_incidents,setList_Of_Incidents] = React.useState([]);

    const  fetchIncidents = async () => { 
        const data = await fetch('http://localhost:3001/control-center/api/incidents', {
          method: 'GET',
          headers: { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + location.state.detail.token
          }
        });
        if(data.status===200){
    
          const incidentData = await data.json();
          const liveIncidents = [];
          incidentData.forEach(incident => {
              if(incident.isOpen){
                  liveIncidents.push(incident);
              }
          });
          setList_Of_Incidents([...liveIncidents]);
        }else{
            console.log(data.status);
        }
      }

    const showLiveIncidents = (event) => {

        //fetch the live incidents
        fetchIncidents();
    }

    const [expanded, setExpanded] = React.useState(false);

    const handleChange2 = (panel) => (event, isExpanded) => {
      setExpanded(isExpanded ? panel : false);
    };
  

    const classes = MyStyles();

    const [open, setOpen] = React.useState(false);
    const [selectedValue, setSelectedValue] = React.useState(locations[1]);
  
    const handleClickOpen = () => {
      setOpen(true);
    };
  
    const handleClose = (value) => {
      setOpen(false);
      setSelectedValue(value);
    };

    // States if checkbox is checked,then allow to pick factor level

    const [checkbox1, setCheckbox1] = React.useState(true);

    const handleVanish1 = () => {
        setCheckbox1(!checkbox1);
    }

    const [checkbox2, setCheckbox2] = React.useState(true);

    const handleVanish2 = () => {
        setCheckbox2(!checkbox2);
    }

    const [checkbox3, setCheckbox3] = React.useState(true);

    const handleVanish3 = () => {
        setCheckbox3(!checkbox3);
    }

    const [checkbox4, setCheckbox4] = React.useState(true);

    const handleVanish4 = () => {
        setCheckbox4(!checkbox4);
    }

    // States gia ta columns apo peristatika.AN kaneis click ston titlo emfanise to boxaki sta de3ia me ta info

    const [value9, setValue9] = React.useState(0);
    const [ekab , setEkab] = React.useState(0);
    const [police , setPolice] = React.useState(0);
    const [marines , setMarines] = React.useState(0);
    const [fireF , setFireF] = React.useState(0);

    // const  getUsersAgency = async () => { 
    //     const data = await fetch('http://localhost:3001/control-center/api/users', {
    //       method: 'GET',
    //       headers: { 
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //         'Authorization': 'Bearer ' + location.state.detail.token
    //       }
    //     });
    //     if(data.status===200){
    
    //       const usersAgency = await data.json();
    //       usersAgency.forEach(user => {
    //           if(user.agency === "ekab"){
    //             setEkab(ekab + 1);
    //           }else if(user.agency === "police"){
    //             setPolice(police + 1);
    //           }else if(user.agency === "marines"){
    //             setMarines(marines + 1);
    //           }else if(user.agency === "fireF"){
    //             setFireF(fireF + 1);
    //           }
    //       });
    //     }else{
    //         console.log(data.status);
    //     }
    //   }

    const handleChange9 = (event, newValue9) => {
        //get the users of the incident 
        let usersInci = [...list_of_incidents[newValue9].users];
        usersInci.forEach(e =>{
            console.log(e);
        });
        //ssearch for their agencies 
        setValue9(newValue9);
    };

   

    // Gia to kleisimo tou peristatikou 

    const [closegamw, setCloseIncident] = React.useState(false);
    
    const handleCloseIncidentOpen = () => {
        setCloseIncident(true);
    }

    const handleCloseIncidentClose = () => {
        setCloseIncident(false);
    }

    const SpecialhandleCloseIncidentClose = (event,tablenum) => { 
        event.preventDefault();
        setCloseIncident(false);
        var joined=list_of_incidents;
        joined.splice(tablenum,1);
        setList_Of_Incidents(joined);
    }

    /*~~~ Gia afairesh-prosthkh organwn uphresias ~~~*/

    const [open2 , setOpen2] = React.useState(false);

    const handleClickOpen2 = () => {
        setOpen2(true);
    };

    const handleClose2 = () => {
        setOpen2(false);
    }

    const [open3 , setOpen3] = React.useState(false);

    const handleClickOpen3 = () => {
        setOpen3(true);
    };

    const handleClose3 = () => {
        setOpen3(false);
    }

    const [open4 , setOpen4] = React.useState(false);

    const handleClickOpen4 = () => {
        setOpen4(true);
    };

    const handleClose4 = () => {
        setOpen4(false);
    }

    const [open5 , setOpen5] = React.useState(false);

    const handleClickOpen5 = () => {
        setOpen5(true);
    };

    const handleClose5 = () => {
        setOpen5(false);
    }


    const [temp , setTemp] = React.useState("");

    const handleTemp = (event) => {
        setTemp(event.target.value);
    }

    const SpecialhandleClose2 = (event,myvalue) => {
        event.preventDefault();
        var joined=list_of_incidents;
        joined[myvalue].Medics=list_of_incidents[myvalue].Medics+parseInt(temp);
        if (joined[myvalue].Medics <= 0) {
            joined[myvalue].Medics = 0 ;
        }
        setList_Of_Incidents(joined);
        setOpen2(false);
    }

    const SpecialhandleClose3 = (event,myvalue) => {
        event.preventDefault();
        var joined=list_of_incidents;
        joined[myvalue].FireFighters=list_of_incidents[myvalue].FireFighters+parseInt(temp);
        if (joined[myvalue].FireFighters <= 0) {
            joined[myvalue].FireFighters = 0 ;
        }
        setList_Of_Incidents(joined);
        setOpen3(false);
    }

    const SpecialhandleClose5 = (event,myvalue) => {
        event.preventDefault();
        var joined=list_of_incidents;
        joined[myvalue].BoatFighters=list_of_incidents[myvalue].BoatFighters+parseInt(temp);
        if (joined[myvalue].BoatFighters <= 0) {
            joined[myvalue].BoatFighters = 0 ;
        }
        setList_Of_Incidents(joined);
        setOpen5(false);
    }

    const SpecialhandleClose4 = (event,myvalue) => {
        event.preventDefault();
        var joined=list_of_incidents;
        joined[myvalue].Cops=list_of_incidents[myvalue].Cops+parseInt(temp);
        if (joined[myvalue].Cops <= 0) {
            joined[myvalue].Cops = 0 ;
        }
        setList_Of_Incidents(joined);
        setOpen4(false);
    }

    //handle title when entering new incident
    const [titleIncident,setTitle]=React.useState("");
    const handleTitle = (e) =>{
        setTitle(e.value);
    }
    //handle the lat and lon when entering a new incident 
    const [latIncident,setLat] = React.useState(0);
    const [lotIncident,setLon] = React.useState(0);
    const handleLat = (e) =>{
        setLat(10);
    }
    const handleLon = (e) =>{
        setLon(20);

    }
    //handle the level of the incident 
    const [levelPIncident,setLevelPolice] = React.useState(0);
    const [levelFIncident,setLevelFireF] = React.useState(0);
    const [levelEIncident,setLevelEkab] = React.useState(0);
    const [levelMIncident,setLevelMarines] = React.useState(0);

    const handleLevelPolice = (e) =>{
        setLevelPolice(e.value);
    }
    const handleLevelEkab = (e) =>{
        setLevelEkab(e.value);
    }
    const handleLevelFireF = (e) =>{
        setLevelFireF(e.value);
    }
    const handleLevelMarines = (e) =>{
        setLevelMarines(e.value);
    }

    const icon_handler=()=>{      
        // console.log("HELLO"); 
        // console.log(currentPath);          
     // Nested list gia ta organa pou summetexoun 

     const [openlist, setOpenList] = React.useState(true);
   
     const handleClick = () => {
       setOpenList(!openlist);
     };

     const [openlist2, setOpenList2] = React.useState(true);
   
     const handleClick2 = () => {
       setOpenList2(!openlist2);
     };

     const [openlist3, setOpenList3] = React.useState(true);
   
     const handleClick3 = () => {
       setOpenList3(!openlist3);
     };

     const [openlist4, setOpenList4] = React.useState(true);
   
     const handleClick4 = () => {
       setOpenList4(!openlist4);
     };

     const [list_of_cops,setList_Of_Cops] = React.useState([
        {
            firstname:"Αντώνης",
            lastname:"Κακαβάς",
            phone:"6984002910"
        },
        {
            firstname:"Μιχάλης",
            lastname:"Μήτσιος",
            phone:"6984002910"
        },
        {
            firstname:"Ερρίκος",
            lastname:"Λατίνος",
            phone:"6984002910"
        }
    ]);

    const [list_of_medics,setList_Of_Medics] = React.useState([
        {
            firstname:"Αντώνηasdς",
            lastname:"Κακαβasdάς",
            phone:"6984002asd910"
        },
        {
            firstname:"Μιχάasdλης",
            lastname:"Μήτσιasdος",
            phone:"6984002asd910"
        },
        {
            firstname:"Ερρίwqκος",
            lastname:"Λατίνasdος",
            phone:"69840029zxc10"
        }
    ]);

    const [list_of_firefighters,setList_Of_FireFighters] = React.useState([
        {
            firstname:"Αντdcxώνης",
            lastname:"Κακαβάvcς",
            phone:"6984002xcv910"
        },
        {
            firstname:"Μιχάλbvnbvης",
            lastname:"Μήτσιvbnvcος",
            phone:"69840029cb10"
        },
        {
            firstname:"Ερρplkίκος",
            lastname:"Λατίνος",
            phone:"6984002hm910"
        }
    ]);

    const [list_of_boats,setList_Of_BoatFighters] = React.useState([
        {
            firstname:"Αντώqsνης",
            lastname:"Κακαqwasβάς",
            phone:"6984002qwas910"
        },
        {
            firstname:"Μιχάλης",
            lastname:"Μήτσιaaszος",
            phone:"6984002910"
        },
        {
            firstname:"Ερρqwaίκος",
            lastname:"Λατίνzsdος",
            phone:"69840029q10"
        }
    ]);
    
            return(
  
                <Box className="icon_color" display="flex" flexDirection="row" justifyContent="flex-end" >
                    <Box mx={3}>
                        <SearchIcon  fontSize='large'></SearchIcon>
                    </Box>
                    <Box mx={3}>
                    <Link to={{
                          pathname: '/Profile_Page',
                          state: { detail : "hahah" }
                         }}>
                        <AccountCircleSharpIcon  fontSize='large'></AccountCircleSharpIcon>
                    </Link>
  
                    </Box>
                    {/* <Box mx={3}>
                        <HelpRoundedIcon  fontSize='large' onClick = {handleClickOpen} ></HelpRoundedIcon>
                    </Box> */}
                </Box>
        );
        
  
    return;
  }

    return (
        
        <div className="Syntonisths_Form">
         <Box className="icon_color" display="flex" flexDirection="row" justifyContent="flex-end" >
                    <Box mx={3}>
                        <SearchIcon  fontSize='large'></SearchIcon>
                    </Box>
                    <Box mx={3}>
                    <Link to={{
                          pathname: '/Profile_Page',
                          state: { detail : location.state.detail }
                         }}>
                        <AccountCircleSharpIcon  fontSize='large'></AccountCircleSharpIcon>
                    </Link>
  
                    </Box>
                    {/* <Box mx={3}>
                        <HelpRoundedIcon  fontSize='large' onClick = {handleClickOpen} ></HelpRoundedIcon>
                    </Box> */}
                </Box>
            <Grid container spacing={3}>

                {/* The first 2 tabs */}

                <Grid item xs={12}>
                        <Tabs
                            value={value}
                            onChange={handleChange}
                            indicatorColor="inherit"
                            textColor="primary"
                            centered
                        >
                            <Tab className={classes.tabsStyle} label="ΝΕΑ ΔΗΛΩΣΗ ΠΕΡΙΣΤΑΤΙΚΟΥ"  {...a11yProps(0)}/>
                            {/* {console.log(props.location.state.detail)} */}
                            <Tab className={classes.tabsStyle} 
                                 onClick={showLiveIncidents}
                                 label="ΕΝΕΡΓΑ ΠΕΡΙΣΤΑΤΙΚΑ"{...a11yProps(1)} 
                                
                          />
                        </Tabs>
                </Grid>

                {/* Tab : Νέα Δήλωση Περιστατικού  */}

                <TabPanel value={value} index={0}>
                    <Grid container justify="center">
                        <Grid container className="title_grid">
                            <Grid item xs={5}>
                                <div className="title_padding">
                                    <Typography align="right">Τίτλος Περιστατικού</Typography>
                                </div>
                            </Grid>
                            <Grid item xs={6}>
                                <div className="title_box">
                                    <TextField className={classes.boxesStyle} 
                                    value={titleIncident} 
                                    onChange={handleTitle} 
                                    align="left" 
                                    id="outlined-basic" 
                                    variant="outlined" 
                                    size="medium"/>
                                </div>
                            </Grid>
                        </Grid>

                        {/* Police Checkbox + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox onClick={handleVanish1} color="primary"></Checkbox> }
                                    label="Αστυνομία"
                                    labelPlacement="end"
                                />
                            </div>
                            <div className="button_group">
                                <ButtonGroup disabled={checkbox1} variant="contained" color="primary" aria-label="outlined primary button group">
                                    <Button>Επίπεδο 1</Button>
                                    <Button>Επίπεδο 2</Button>
                                    <Button>Επίπεδο 3</Button>
                                </ButtonGroup>
                            </div>
                        </Grid>

                        {/* EKAB Checkbox + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox onClick={handleVanish2} color="primary"></Checkbox> }
                                    label="ΕΚΑΒ"
                                    labelPlacement="end"
                                />
                            </div>
                            <ButtonGroup disabled={checkbox2} variant="contained" color="primary" aria-label="outlined primary button group">
                                <Button>Επίπεδο 1</Button>
                                <Button>Επίπεδο 2</Button>
                                <Button>Επίπεδο 3</Button>
                            </ButtonGroup>
                        </Grid>

                        {/* Firefighters Checkbox + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox onClick={handleVanish3} color="primary"></Checkbox> }
                                    label="Πυροσβεστική"
                                    labelPlacement="end"
                                />
                            </div>
                            <ButtonGroup disabled={checkbox3} variant="contained" color="primary" aria-label="outlined primary button group">
                                <Button>Επίπεδο 1</Button>
                                <Button>Επίπεδο 2</Button>
                                <Button>Επίπεδο 3</Button>
                            </ButtonGroup>
                        </Grid>

                        {/* Port authority + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox onClick={handleVanish4} color="primary"></Checkbox> }
                                    label="Λιμενικό"
                                    labelPlacement="end"
                                />
                            </div>
                            <ButtonGroup disabled={checkbox4} variant="contained" color="primary" aria-label="outlined primary button group">
                                <Button>Επίπεδο 1</Button>
                                <Button>Επίπεδο 2</Button>
                                <Button>Επίπεδο 3</Button>
                            </ButtonGroup>
                        </Grid>

                        {/* Location + Its box */}

                        <Grid container className="incident_phone_grid">
                            <Grid item xs={5}>
                                <div className="title_padding">
                                    <Typography align="right">Τοποθεσία Συμβάντος</Typography>
                                </div>
                            </Grid>
                            <Grid item xs={6}>
                                <div className="title_box">
                                    <TextField 
                                    className={classes.boxesStyle} 
                                    align="left" id="outlined-basic" 
                                    variant="outlined" 
                                    size="medium"
                                    InputProps={{
                                        startAdornment: (
                                        <InputAdornment position="start">
                                            <LocationOnIcon />
                                    </InputAdornment>
                                        ),
                                    }}
                                    />
                                </div>
                            </Grid>
                        </Grid>
                        
                        {/* PhoneNumber + Its box */}

                        <Grid container className="location_grid">
                            <Grid item xs={5}>
                                <div className="phone_padding">
                                    <Typography align="right">Τηλέφωνο Επικοινωνίας</Typography>
                                </div>
                            </Grid>
                            <Grid item xs={6}>
                                <div className="phone_box">
                                    <TextField 
                                    className={classes.boxesStyle} 
                                    align="left" id="outlined-basic" 
                                    variant="outlined" 
                                    size="medium"
                                    InputProps={{
                                        startAdornment: (
                                        <InputAdornment position="start">
                                            <PhoneIcon />
                                    </InputAdornment>
                                        ),
                                    }}
                                    />
                                </div>
                            </Grid>
                        </Grid>
                        
                        {/* Submit button */}

                        <Grid container className="grid_submit_button" justify="center">
                                <Button
                                    className="submit_button"
                                    variant="contained"
                                    color="primary"
                                >
                                    ΔΗΛΩΣΗ
                                </Button>
                        </Grid>

                    </Grid>

                </TabPanel>

                {/* Tab : ΕΝΕΡΓΑ ΠΕΡΙΣΤΑΤΙΚΑ */}

                <TabPanel className="existing_incidents_tabpanel" value={value} index={1}>
                    <Grid container spacing={3} className="open_incidents_gr">

                        {/* Περιστατικά Columns */}
                        
                        <Grid item xs={2} class="incidents_Col"> {/* Για το column με τα περιστατικά */}
                            <Grid container direction="column" spacing={12} className="incidents_column">

                                <Tabs
                                        orientation="vertical"
                                        variant="scrollable"
                                        value={value9}
                                        onChange={handleChange9}
                                        aria-label="Vertical tabs example"
                                        className="peristatiko_tab"
                                >
                                    {list_of_incidents.map((item,index_num) =>                     
                                        <Tab key={index_num} label={item.title} {...a12yProps(index_num)} />
                                    )}    
                                </Tabs> 
                            </Grid>
                        </Grid> { /* Grid gia to column me ta peristatika */}

                        <Grid item xs={9} className="open_incident_info">
                            {/* <Grid container direction="row" spacing={12}> */}
                            {list_of_incidents.map((item,index_num) =>
                                <TabPanel value={value9} key={index_num} index={index_num}>
                                    <Grid container>
                                        <Grid item xs={3} classname="peristatiko_tab_sto_kouti">
                                            <TextField
                                                
                                                id="standard-disabled"
                                                defaultValue={item.title}
                                                multiline
                                                fullWidth
                                                InputProps={{
                                                    readOnly: true,
                                                  }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={9}>
                                            <Grid container justify="flex-end">
                                                <div className="close_incident"> {/* This class doesnt work.Idk why.. */}
                                                    <Button onClick={handleCloseIncidentOpen} className="fuckyou"variant="contained" startIcon={<CloseIcon />}>
                                                        ΚΛΕΙΣΙΜΟ ΠΕΡΙΣΤΑΤΙΚΟΥ
                                                    </Button>
                                                    <Dialog
                                                        open={closegamw}
                                                        onClose={handleCloseIncidentClose}
                                                        aria-labelledby="alert-dialog-title"
                                                        aria-describedby="alert-dialog-description"
                                                    >
                                                        <DialogTitle id="alert-dialog-title">{"Επιβεβαίωση κλεισίματος Περιστατικού"}</DialogTitle>
                                                        <DialogContent>
                                                            <DialogContentText id="alert-dialog-description">
                                                               Είστε σίγουρος ότι θέλετε να κλείσετε το περιστατικό ? Δεν υπάρχει επιστροφή αν πατήσετε
                                                               επιβεβαίωση.
                                                            </DialogContentText>
                                                        </DialogContent>
                                                        <DialogActions>
                                                            <Button onClick={handleCloseIncidentClose} color="primary">
                                                               ΑΚΎΡΩΣΗ 
                                                            </Button>
                                                            <Button onClick={(event) => {SpecialhandleCloseIncidentClose(event,value9)}}  color="primary">
                                                                ΕΠΙΒΕΒΑΊΩΣΗ
                                                            </Button>
                                                        </DialogActions>
                                                    </Dialog>
                                                </div>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                    <Grid container>
                                        <Grid item xs={3}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Τοποθεσία"
                                                defaultValue={ "lat: " +  list_of_incidents[value9].x + " - lon: " +  list_of_incidents[value9].y}
                                                InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <LocationOnIcon></LocationOnIcon>
                                                        </InputAdornment>
                                                    ),
                                                    readOnly : true,
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={6} className="change_location">
                                            <Button variant="outlined" color="primary" onClick={handleClickOpen}>
                                                Αλλαγή τοποθεσίας
                                            </Button>
                                            
                                            <SimpleDialog moreimp={setList_Of_Incidents} important={list_of_incidents} position={list_of_incidents[value9].position} pvalue={value9} selectedValue={selectedValue} open={open} onClose={handleClose} />
                                        </Grid>Τίτλος Περιστατικού
                                        <Grid item xs={7}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Τηλέφωνο"
                                                defaultValue={list_of_incidents[value9].telephone}
                                                InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <PhoneIcon></PhoneIcon>
                                                        </InputAdornment>
                                                    ),
                                                    readOnly : true,
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                    </Grid>
                                    <Grid container className="services_titles" direction="row">
                                        
                                        <Grid item xs={3} value={value9} key={index_num} index={index_num}>
                                            <Typography>ΕΚΑΒίτες</Typography>
                                            <TextField
                                                value={list_of_incidents[value9].Medics}
                                                // inputProps={{ min: 0, max: 103}}
                                                InputProps={{
                                                    startAdornment: (
                                                    <InputAdornment position="start">
                                                        <LocalHospitalIcon></LocalHospitalIcon>
                                                    </InputAdornment>
                                                    ),
                                                    readOnly : true,
                                                }}
                                            >
                                            </TextField>
                                            <Fab onClick={handleClickOpen2} className="pluspersonel" color="secondary" aria-label="add" size="small">
                                                <AddIcon />
                                            </Fab>
                                            <Dialog
                                                open={open2}
                                                onClose={handleClose2}
                                                aria-labelledby="alert-dialog-title"
                                                aria-describedby="alert-dialog-description"
                                            >
                                                <DialogTitle>{"Προσθήκη / Αφαίρεση Οργάνων Υπηρεσίας"}</DialogTitle>
                                                <DialogContent>
                                                    <TextField
                                                        label="Αυξομείωση του Προσωπικού"
                                                        type="number"
                                                        value={temp}
                                                        onChange={handleTemp}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                          }}
                                                    >
                                                    </TextField>
                                                </DialogContent>
                                                <DialogActions>
                                                    <Button onClick={handleClose2} color="primary">
                                                        ΑΚΎΡΩΣΗ
                                                    </Button>
                                                    <Button onClick={(event) => {SpecialhandleClose2(event,value9)}} color="primary">
                                                        ΕΠΙΒΕΒΑΊΩΣΗ
                                                    </Button>
                                                </DialogActions>
                                            </Dialog>
                                            {/* Nested List για τα Οργανα που συμμετεχουν  */}

                                            <Grid container className="list_of_participants" direction="column">
                                                <List>
                                                    <ListItem button onClick={handleClick}>
                                                        <ListItemText primary="Στοιχεία Συμμετέχοντων">
                                                        </ListItemText>
                                                        {open ? <ExpandLess /> : <ExpandMore />}
                                                    </ListItem>
                                                    <Collapse in={openlist} timeout="auto" unmountOnExit>
                                                        

                                                        {/* To list gia ta stoixeia kathe organou */}
                                                        
                                                        {list_of_medics.slice(0,list_of_incidents[value9].Medics).map((item,index_num) =>
                                                            <List disablePadding key={index_num} index={index_num}>
                                                                <ListSubheader>
                                                                    ΟΡΓΑΝΟ ΥΠΗΡΕΣΙΑΣ
                                                                </ListSubheader>
                                                                <ListItem >
                                                                    <ListItemText primary={item.firstname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.lastname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.phone}></ListItemText>
                                                                </ListItem>
                                                            </List>
                                                        )}
                                                    </Collapse> 
                                                </List>
                                            </Grid>
                                        </Grid>
                                        
                                        
                                        <Grid item xs={3}>
                                            <Typography>Πυροσβέστες</Typography>
                                            <TextField
                                            // defaultValue={item.FireFighters}
                                            value={list_of_incidents[value9].FireFighters}
                                                InputProps={{
                                                    startAdornment: (
                                                      <InputAdornment position="start">
                                                        <WhatshotIcon></WhatshotIcon>
                                                      </InputAdornment>
                                                    ),
                                                    readOnly : true,
                                                  }}
                                            >
                                            </TextField>
                                            <Fab onClick={handleClickOpen3} className="pluspersonel" color="secondary" aria-label="add" size="small">
                                                <AddIcon />
                                            </Fab>
                                            <Dialog
                                                open={open3}
                                                onClose={handleClose3}
                                                aria-labelledby="alert-dialog-title"
                                                aria-describedby="alert-dialog-description"
                                            >
                                                <DialogTitle>{"Προσθήκη / Αφαίρεση Οργάνων Υπηρεσίας"}</DialogTitle>
                                                <DialogContent>
                                                    <TextField
                                                        label="Αυξομείωση του Προσωπικού"
                                                        type="number"
                                                        value={temp}
                                                        onChange={handleTemp}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                          }}
                                                    >
                                                    </TextField>
                                                </DialogContent>
                                                <DialogActions>
                                                    <Button onClick={handleClose3} color="primary">
                                                        ΑΚΎΡΩΣΗ
                                                    </Button>
                                                    <Button onClick={(event) => {SpecialhandleClose3(event,value9)}} color="primary">
                                                        ΕΠΙΒΕΒΑΊΩΣΗ
                                                    </Button>
                                                </DialogActions>
                                            </Dialog>

                                            {/* Nested List για τα Οργανα που συμμετεχουν  */}

                                            <Grid container className="list_of_participants" direction="column">
                                                <List>
                                                    <ListItem button onClick={handleClick2}>
                                                        <ListItemText primary="Στοιχεία Συμμετέχοντων">
                                                        </ListItemText>
                                                        {open ? <ExpandLess /> : <ExpandMore />}
                                                    </ListItem>
                                                    <Collapse in={openlist2} timeout="auto" unmountOnExit>
                                                        

                                                        {/* To list gia ta stoixeia kathe organou */}
                                                        
                                                        {list_of_firefighters.slice(0,list_of_incidents[value9].FireFighters).map((item,index_num) =>
                                                            <List disablePadding key={index_num} index={index_num}>
                                                                <ListSubheader>
                                                                    ΟΡΓΑΝΟ ΥΠΗΡΕΣΙΑΣ
                                                                </ListSubheader>
                                                                <ListItem >
                                                                    <ListItemText primary={item.firstname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.lastname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.phone}></ListItemText>
                                                                </ListItem>
                                                            </List>
                                                        )}
                                                    </Collapse> 
                                                </List>
                                            </Grid>

                                        </Grid>

                                        <Grid item xs={3}>
                                            <Typography>Αστυνομικοί</Typography>
                                            <TextField
                                            // defaultValue={item.Cops}
                                            value={list_of_incidents[value9].Cops}
                                                InputProps={{
                                                    startAdornment: (
                                                      <InputAdornment position="start">
                                                        <SecurityIcon></SecurityIcon>
                                                      </InputAdornment>
                                                    ),
                                                    readOnly : true,
                                                  }}
                                            >
                                            </TextField>
                                            <Fab onClick={handleClickOpen4} className="pluspersonel" color="secondary" aria-label="add" size="small">
                                                <AddIcon />
                                            </Fab>
                                            <Dialog
                                                open={open4}
                                                onClose={handleClose4}
                                                aria-labelledby="alert-dialog-title"
                                                aria-describedby="alert-dialog-description"
                                            >
                                                <DialogTitle>{"Προσθήκη / Αφαίρεση Οργάνων Υπηρεσίας"}</DialogTitle>
                                                <DialogContent>
                                                    <TextField
                                                        label="Αυξομείωση του Προσωπικού"
                                                        type="number"
                                                        value={temp}
                                                        onChange={handleTemp}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                          }}
                                                    >
                                                    </TextField>
                                                </DialogContent>
                                                <DialogActions>
                                                    <Button onClick={handleClose4} color="primary">
                                                        ΑΚΎΡΩΣΗ
                                                    </Button>
                                                    <Button onClick={(event) => {SpecialhandleClose4(event,value9)}} color="primary">
                                                        ΕΠΙΒΕΒΑΊΩΣΗ
                                                    </Button>
                                                </DialogActions>
                                            </Dialog>

                                            {/* Nested List για τα Οργανα που συμμετεχουν  */}

                                            <Grid container className="list_of_participants" direction="column">
                                                <List>
                                                    <ListItem button onClick={handleClick3}>
                                                        <ListItemText primary="Στοιχεία Συμμετέχοντων">
                                                        </ListItemText>
                                                        {open ? <ExpandLess /> : <ExpandMore />}
                                                    </ListItem>
                                                    <Collapse in={openlist3} timeout="auto" unmountOnExit>
                                                        

                                                        {/* To list gia ta stoixeia kathe organou */}
                                                        
                                                        {list_of_cops.slice(0,list_of_incidents[value9].Cops).map((item,index_num) =>
                                                            <List disablePadding key={index_num} index={index_num}>
                                                                <ListSubheader>
                                                                    ΟΡΓΑΝΟ ΥΠΗΡΕΣΙΑΣ
                                                                </ListSubheader>
                                                                <ListItem >
                                                                    <ListItemText primary={item.firstname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.lastname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.phone}></ListItemText>
                                                                </ListItem>
                                                            </List>
                                                        )}
                                                    </Collapse> 
                                                </List>
                                            </Grid>


                                        </Grid>


                                        <Grid item xs={3}>
                                            <Typography>Λιμενικοί</Typography>
                                            <TextField
                                            // defaultValue={item.BoatFighters}
                                            value={list_of_incidents[value9].BoatFighters}
                                                InputProps={{
                                                    startAdornment: (
                                                      <InputAdornment position="start">
                                                        <DirectionsBoatIcon></DirectionsBoatIcon>
                                                      </InputAdornment>
                                                    ),
                                                    readOnly : true,
                                                  }}
                                            >
                                            </TextField>
                                            <Fab onClick={handleClickOpen5} className="pluspersonel" color="secondary" aria-label="add" size="small">
                                                <AddIcon />
                                            </Fab>
                                            <Dialog
                                                open={open5}
                                                onClose={handleClose5}
                                                aria-labelledby="alert-dialog-title"
                                                aria-describedby="alert-dialog-description"
                                            >
                                                <DialogTitle>{"Προσθήκη / Αφαίρεση Οργάνων Υπηρεσίας"}</DialogTitle>
                                                <DialogContent>
                                                    <TextField
                                                        label="Αυξομείωση του Προσωπικού"
                                                        type="number"
                                                        value={temp}
                                                        onChange={handleTemp}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                          }}
                                                    >
                                                    </TextField>
                                                </DialogContent>
                                                <DialogActions>
                                                    <Button onClick={handleClose5} color="primary">
                                                        ΑΚΎΡΩΣΗ
                                                    </Button>
                                                    <Button onClick={(event) => {SpecialhandleClose5(event,value9)}} color="primary">
                                                        ΕΠΙΒΕΒΑΊΩΣΗ
                                                    </Button>
                                                </DialogActions>
                                            </Dialog>

                                            {/* Nested List για τα Οργανα που συμμετεχουν  */}

                                            <Grid container className="list_of_participants" direction="column">
                                                <List>
                                                    <ListItem button onClick={handleClick4}>
                                                        <ListItemText primary="Στοιχεία Συμμετέχοντων">
                                                        </ListItemText>
                                                        {open ? <ExpandLess /> : <ExpandMore />}
                                                    </ListItem>
                                                    <Collapse in={openlist4} timeout="auto" unmountOnExit>
                                                        

                                                        {/* To list gia ta stoixeia kathe organou */}
                                                        
                                                        {list_of_boats.slice(0,list_of_incidents[value9].BoatFighters).map((item,index_num) =>
                                                            <List disablePadding key={index_num} index={index_num}>
                                                                <ListSubheader>
                                                                    ΟΡΓΑΝΟ ΥΠΗΡΕΣΙΑΣ
                                                                </ListSubheader>
                                                                <ListItem >
                                                                    <ListItemText primary={item.firstname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.lastname}></ListItemText>
                                                                </ListItem>
                                                                <ListItem >
                                                                    <ListItemText primary={item.phone}></ListItemText>
                                                                </ListItem>
                                                            </List>
                                                        )}
                                                    </Collapse> 
                                                </List>
                                            </Grid>
                                                          
                                        </Grid>

                                    </Grid>
                                </TabPanel>
                            )}
                            {/* </Grid> */}
                        </Grid> { /* Grid gia to pinakaki de3ia me ta info */}
                                
                    </Grid> { /* ENERGA PERISTATIKA GRID ( OLO TO TAB) */}
                </TabPanel>
            </Grid>
        </div>
    );
}