import React ,{Component} from 'react';
import Grid from '@material-ui/core/Grid';
// import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
// import { withStyles } from '@material-ui/styles';
// import TextField from '@material-ui/core/TextField';
// import Button from '@material-ui/core/Button';
// import Alert from '@material-ui/lab/Alert';
// import Snackbar from '@material-ui/core/Snackbar';

// import InputLabel from '@material-ui/core/InputLabel';
// import MenuItem from '@material-ui/core/MenuItem';
// import FormControl from '@material-ui/core/FormControl';
// import Select from '@material-ui/core/Select';

import Syntonistis_form from './New_Syntonistis_form';
import Open_Incidents from './Open_incidents.js';

import './Syntonistis_Page.css';


function TabPanel(props) {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`scrollable-auto-tabpanel-${index}`}
        aria-labelledby={`scrollable-auto-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box p={3}>
            <Typography component={'div'}>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }
  
  TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
  };

function a11yProps(index) {
    return {
      id: `scrollable-auto-tab-${index}`,
      'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
  }


class Syntonistis_Page extends Component{
    constructor(props){
        super(props);

        this.state={
            value:0,
            agencies:[]
        }        
        

        this.handleClickValue=this.handleClickValue.bind(this);
        
    }


    handleClickValue = (event,newValue) => {
        this.setState({  
            value: newValue 
        });
    };
     
    fetchAgencies = async () => { 
      const data = await fetch('http://localhost:3001/control-center/api/agencies', {
        method: 'GET',
        headers: { 
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + this.props.location.state.detail.token
        }
      });
      if(data.status===200){
  
        const agenciesData = await data.json();
        // console.log(agenciesData);
        //create a 2 dimensional array with the name of the agency and it's id
        let newArray=[];
        agenciesData.forEach(i => {
          newArray.push({"agencyName" : i.name , "agencyId" : i._id});
        });         
        this.setState(()=> ({
            agencies : newArray
        }));
        // console.log(this.state.agencies);

      }else{
        console.log("Error Code : " + data.status + "\nError Message : " + data.statusText);
      }
    }
    componentDidMount(){
      this.fetchAgencies();

    }
    
      render(){
        return(
            <div>
                <div className="Syntonisths_Form">
                <Grid container spacing={3}>

                    {/* The first 2 tabs */}

                    <Grid item xs={12}>
                            <Tabs
                                value={this.state.value}
                                onChange={this.handleClickValue}
                                textColor="primary"
                                centered
                            >
                                <Tab className="tabsStyle" label="ΝΕΑ ΔΗΛΩΣΗ ΠΕΡΙΣΤΑΤΙΚΟΥ" {...a11yProps(1)} />
                                <Tab className="tabsStyle" label="ΕΝΕΡΓΑ ΠΕΡΙΣΤΑΤΙΚΑ" {...a11yProps(0)}/>

                            </Tabs>
                            <TabPanel value={this.state.value} index={0}>
                                <Syntonistis_form agencies={this.state.agencies} bearerToken={this.props.location.state.detail.token} ></Syntonistis_form>
                            </TabPanel>
                            <TabPanel value={this.state.value} index={1}>
                                <Open_Incidents  bearerToken={this.props.location.state.detail.token} agencies={this.state.agencies} ></Open_Incidents>
                            </TabPanel>
                    </Grid>
                </Grid>
                </div>
            </div>
        );
    }

}

export default Syntonistis_Page;