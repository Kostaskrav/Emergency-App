import React from 'react';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import TextField from '@material-ui/core/TextField';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import InputAdornment from '@material-ui/core/InputAdornment';

function SimpleDialog(props) {

    // const classes = MyStyles();
    const { onClose, selectedValue, open,pvalue,important,moreimp } = props;

    // console.log("Skata"+pvalue);
  
    const handleClose = () => {
      onClose(selectedValue);
    };
  
    // const handleListItemClick = (value) => {
    //   onClose(value);
    // };

    const [temp2 , setTemp2] = React.useState("");

    const handleTemp2 = (event) => {
        setTemp2(event.target.value);
    }

    const SpecialhandleClose = (event,thevalue) => {
        // console.log("The value is:"+thevalue);
        // console.log("Temp2 is :"+temp2);
        // console.log("Important position is :"+important.position);
        event.preventDefault();
        var joined=important;
        joined[thevalue].position=temp2;
        moreimp(joined);
        onClose(selectedValue);
    }

    return (
        <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open}>
            <DialogTitle id="simple-dialog-title">Αλλαγή τρέχουσας τοποθεσίας</DialogTitle>
            
                
                 {/* <ListItem onClick={() => handleListItemClick(props.position)}> */}
                    <List>
                        <ListItem>
                            <TextField 
                            // className={classes.margin}
                                id="input-with-icon-textfield"
                                label="Παλιά Τοποθεσία"
                                defaultValue={props.position}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <LocationOnIcon></LocationOnIcon>
                                        </InputAdornment>
                                    ),
                                    readOnly : true,
                                }}
                            >
                            </TextField>
                        </ListItem>
                        <ListItem>
                            <TextField 
                            // className={classes.margin}
                                id="input-with-icon-textfield"
                                label="Νέα Τοποθεσία"
                                value={temp2}
                                onChange={handleTemp2}
                                InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <LocationOnIcon></LocationOnIcon>
                                    </InputAdornment>
                                ),
                                }}
                            >
                            </TextField> 
                        </ListItem>
                    </List>
                {/* </ListItem> */}
            <DialogActions>
                <Button onClick={handleClose} color="primary">
                    Ακύρωση
                </Button>
                <Button onClick={(event) => {SpecialhandleClose(event,pvalue)}} color="primary">
                    Επιβεβαίωση Αλλαγής
                </Button>
            </DialogActions>       
        </Dialog>
    );
}

export default SimpleDialog;