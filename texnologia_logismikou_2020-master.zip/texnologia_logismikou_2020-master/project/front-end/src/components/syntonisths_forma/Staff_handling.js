import React, { Component, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import TextField from '@material-ui/core/TextField';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import DialogContent from '@material-ui/core/DialogContent';
import InputAdornment from '@material-ui/core/InputAdornment';
import LocalHospitalIcon from '@material-ui/icons/LocalHospital';
import Typography from '@material-ui/core/Typography';

import './Staff_handling.css';

function Staff_handling(props) {
    const {Service,users,agencies } = props;
    const [temp , setTemp] = React.useState(0);
    // const [len,setLen] = React.useState(0);

    const handleTemp = (event) => {
        setTemp(event.target.value);
    }
    const SpecialhandleClose = (event,myvalue,index) => {
         event.preventDefault();                                 //  todo this function!!
        // var joined=props.list_of_incidents;
        // joined[myvalue][props.Service]=props.list_of_incidents[myvalue][props.Service]+parseInt(temp);
        // props.setList_Of_Incidents(joined);
        // setTemp(0);
        // props.handleClose_modal(index);
    }
    //return the number of users of each agency in the incident 
    //we got this.props.users to find which agencies are active in this incident
    //we got the agency name in this.props.Service
    //and get their id;
    const returnInitialValue = () => {
        const arrayOfKeys = Object.keys(users);
        let len=0;
       // setKeys(Object.keys(users));
        if(Service === "Medics"){
            //search in the agencies to fins their id 
            agencies.forEach(element => {
                if(element.agencyName=== "Hospital"){
                     //search the incident's users array
                        if(arrayOfKeys.includes(element.agencyId)){
                        //get the amount of users active 
                        len = users[element.agencyId].length;
                    }
                    
                }
            });
            
        }
        else if(Service === "FireFighters"){
            agencies.forEach(element => {
                if(element.agencyName=== "Fire Department"){
                    //search the incident's users array
                       if(arrayOfKeys.includes(element.agencyId)){
                       //get the amount of users active 
                        len = users[element.agencyId].length;                   }
                   
               }
            });
        }
        else if(Service === "BoatFighters"){
            agencies.forEach(element => {
                if(element.agencyName=== "Navy"){
                    //search the incident's users array
                       if(arrayOfKeys.includes(element.agencyId)){
                       //get the amount of users active 
                        len = users[element.agencyId].length;                   }
                   
               }
            });
        }
        else if(Service === "Cops"){
            agencies.forEach(element => {
                if(element.agencyName=== "Police"){
                    //search the incident's users array
                       if(arrayOfKeys.includes(element.agencyId)){
                       //get the amount of users active 
                        len = users[element.agencyId].length;                   }
                   
               }
            });
        }
        // console.log(len + Service);
        return len;

    }

    return(
        <div>
            <Typography>{Service}</Typography>
             <TextField
            value={returnInitialValue()}
          //  defaultValue={}
                InputProps={{
                    startAdornment: (
                    <InputAdornment position="start">
                        <LocalHospitalIcon></LocalHospitalIcon>
                    </InputAdornment>
                    ),
                    readOnly : true,
                }}
            >
            </TextField>
            <Fab onClick={()=>props.handleClickOpen_modal(props.index)} className="pluspersonel" color="secondary" aria-label="add" size="small">
                <AddIcon />
            </Fab>
            <Dialog
                open={props.open_modal[props.index]}
                onClose={()=>props.handleClose_modal(props.index)}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle>{"Προσθήκη Οργάνων Υπηρεσίας "+props.Service}</DialogTitle>
                <DialogContent>
                    <TextField
                        label="Προσθήκη Προσωπικού"
                        type="number"
                        min="0"
                        value={temp}
                        onChange={handleTemp}
                        InputLabelProps={{
                            shrink: true,
                            }}
                    >
                    </TextField>
                </DialogContent>
                <DialogActions>
                    <Button onClick={()=>props.handleClose_modal(props.index)} color="primary">
                        ΑΚΎΡΩΣΗ
                    </Button>
                    <Button onClick={(event) => {SpecialhandleClose(event,props.value,props.index)}} color="primary">
                        ΕΠΙΒΕΒΑΊΩΣΗ
                    </Button> 
                </DialogActions>
            </Dialog> 
        </div>
    );
    

}

export default Staff_handling;