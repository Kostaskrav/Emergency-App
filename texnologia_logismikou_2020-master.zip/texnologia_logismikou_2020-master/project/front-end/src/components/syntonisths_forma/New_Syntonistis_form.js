import React ,{Component} from 'react';
import Grid from '@material-ui/core/Grid';
// import AppBar from '@material-ui/core/AppBar';
// import Tabs from '@material-ui/core/Tabs';
// import Tab from '@material-ui/core/Tab';
// import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
// import Box from '@material-ui/core/Box';
// import { withStyles } from '@material-ui/styles';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
// import ButtonGroup from '@material-ui/core/ButtonGroup';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import InputAdornment from '@material-ui/core/InputAdornment';
import PhoneIcon from '@material-ui/icons/Phone';
import ToggleButton from '@material-ui/lab/ToggleButton';
import ToggleButtonGroup from '@material-ui/lab/ToggleButtonGroup';
import Alert from '@material-ui/lab/Alert';
// import InputLabel from '@material-ui/core/InputLabel';
// import MenuItem from '@material-ui/core/MenuItem';
// import FormControl from '@material-ui/core/FormControl';
// import Select from '@material-ui/core/Select';
import Snackbar from '@material-ui/core/Snackbar';
import InfoIcon from '@material-ui/icons/Info';




import './New_Syntonistis_form.css';
import { IconButton } from '@material-ui/core';

class Syntonisths_Form extends Component{
    constructor(props){
        super(props);

        this.state={
            // value:0,
            checkbox:[true,true,true,true],
            Level:[0,0,0,0],
            index_num:0,
            location_X:"",
            location_Y:"",
            phone:"",
            title:"",
            startDate : new Date().toLocaleString(), //sample
            endDate : "3" ,//sample,
            isOpen : true,
            showSuccessSend:false,
            openSnackBar:false,
            submit_disabled:true,
            showWarningMessage:false,
            levelJson : {}
        }        
        
        this.Set_index_num=this.Set_index_num.bind(this);
        this.handleClickValue=this.handleClickValue.bind(this);
        this.handleVanishButtons=this.handleVanishButtons.bind(this);
        this.handleLevelArray=this.handleLevelArray.bind(this);
        this.Handle_title=this.Handle_title.bind(this);
        this.Handle_location_X=this.Handle_location_X.bind(this);
        this.Handle_location_Y=this.Handle_location_Y.bind(this);
        this.Handle_phone=this.Handle_phone.bind(this);
        this.reset_all=this.reset_all.bind(this);
        this.handleCloseSnackBar=this.handleCloseSnackBar.bind(this);
        this.handleClickSnackBar=this.handleClickSnackBar.bind(this);
        this.handleOpenSnackBar=this.handleOpenSnackBar.bind(this);
        this.handleSubmitButtonStatus=this.handleSubmitButtonStatus.bind(this);
        this.handleWarningMessage=this.handleWarningMessage.bind(this);
        this.handleCloseWarningSnackBar=this.handleCloseWarningSnackBar.bind(this);
    }
    // index_num=0
    Set_index_num(value){
        this.setState({
            index_num:value
        })
    }

    Handle_title=(event)=>{
        this.setState({
            title:event.target.value
        })
    }
    Handle_location_X=(event)=>{

        // console.log("re"+event.target.value);

        const onlyNums = /^[0-9\b]+$/;
        if (event.target.value === '' || onlyNums.test(event.target.value)) {
            this.setState({ 
                location_X:event.target.value
            })
         }

    }

    Handle_location_Y=(event)=>{
        // console.log("re"+event.target.value);

        const onlyNums2 = /^[0-9\b]+$/;
        if (event.target.value === '' || onlyNums2.test(event.target.value)) {
            this.setState({ 
                location_Y:event.target.value
            })
         }
    }

    Handle_phone=(event)=>{
        const onlyNums3 = /^[0-9\b]+$/;

        // console.log(event.target.value.length+"EDW RE FILE EDWWWW")

        if (event.target.value === '' || onlyNums3.test(event.target.value)) {
            this.setState({
                phone:event.target.value
            })
        }
    }


    handleVanishButtons=(index)=>{
        var joined=this.state.checkbox;
        joined[index]=!joined[index];
        this.setState({
            checkbox:joined
        })

    }

    handleLevelArray=(event,NewArrayi,index)=>{
        
        // console.log(NewArrayi+ " INDEX: "+index);
        var joined=this.state.Level;
        joined[index]=NewArrayi;
        this.setState({
            Level:joined
        });
       

    }

    handleClickValue = (event,newValue) => {
        this.setState({  
            value: newValue 
        });
    }

    createIncident = async () => { 
     
        //create the request for the levels
        //we got the agencies array of objects from syntonisths_page in this.props.agencies
        // console.log(this.state.Level);
        // console.log(this.state.checkbox);
        var i;
        for( i=0  ; i < this.state.Level.length ; i++){
            //pros to paron exoume 1)astinomia 2) ekab 3)firefers 4)limeniko
            if(!this.state.checkbox[i]){
                //search in the this.props.agencies for the id of each agency 
                this.props.agencies.forEach(element => {
                    if(i===0){
                        if(element.agencyName === "Police"){
                            this.state.levelJson[element.agencyId] = this.state.Level[i]+1;
                        }
                    }
                    else if(i===2){
                        if(element.agencyName === "Fire Department"){
                            this.state.levelJson[element.agencyId] = this.state.Level[i]+1;

                        }
                    }
                    else if(i===1){
                        if(element.agencyName === "Hospital"){
                            this.state.levelJson[element.agencyId] = this.state.Level[i]+1;

                        }
                    }
                    else if(i===3){
                        if(element.agencyName === "Navy"){
                            this.state.levelJson[element.agencyId] = this.state.Level[i]+1;

                        }
                    }
                });
               
            }
        }
        // console.log(this.state.levelJson);
        

        const data = await fetch('http://localhost:3001/control-center/api/incidents', {
          method: 'POST',
          headers: { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + this.props.bearerToken
          },
          body: JSON.stringify({
              title : this.state.title,
              x : this.state.location_X,
              y : this.state.location_Y ,
              telephone : this.state.phone,
              level : this.state.levelJson ,
              startDate : new Date().toLocaleString(), //hardcoded for the time being
              endDate : this.state.endDate, //hardcoded for the time being
              isOpen : this.state.isOpen,
          })
        });
        if(data.status===200){
            console.log("Status Code : " + data.status + "\n Message : " + data.statusText);          
        }
        else{
          console.log("Error Code : " + data.status + "\nError Message : " + data.statusText);
        }
      }

      reset_all=()=>{
        // console.log("MALAKA");
        this.setState({  
            checkbox:[true,true,true,true],
            Level:[0,0,0,0],
            index_num:0,
            location_X:"",
            location_Y:"",
            phone:"",
            title:"",
            levelJson : {}
        });
      }

    submit_handler=(event)=>{
        event.preventDefault();
        this.handleClickSnackBar();
        this.reset_all();
        this.createIncident();
        // console.log(this.state.title);
        // console.log(this.state.location_X);
        // console.log(this.state.location_Y);
        // console.log(this.state.phone);
        
    }

    /* Enable the disabled Submit BUtton */

    handleSubmitButtonStatus = () => {
        // console.log(this.state.title);
        // console.log(this.state.location_X);
        // console.log(this.state.location_Y);
        // console.log(this.state.phone);
        
        if (this.state.location_X === "" || this.state.location_Y === "" || this.state.phone === "" || this.state.title === "") {
            console.log("Something is empty so keep the button disabled.");
            return true;
        }
        else {
            if (this.state.checkbox[0] === true && this.state.checkbox[1] === true && this.state.checkbox[2] === true && this.state.checkbox[3] === true ) {
                return true;
            }
            if (this.state.phone.length === 10) { /* Phone box must contain exactly 10 numbers */
                return false;
            }
            else {
                return true;
            }
        }
    }

    /* SnackBar Needed Code */

    handleOpenSnackBar = () => {
        this.setState({
            openSnackBar:false,
        })
    }

    handleClickSnackBar = () => {
        this.setState({
            showSuccessSend:true,
        });
    }

    handleCloseSnackBar = (event, reason) => {

        if (reason === 'clickaway') {
          return;
        }

        this.setState({  
            showSuccessSend: false ,
          });

        
    }

    /* Phone Box Warning Message */

    

    handleWarningMessage = () => {
        // console.log("MPKAME");
        this.setState({
            showWarningMessage: true,
        })
    }

    handleCloseWarningSnackBar = (event, reason) => {
        if (reason === 'clickaway') {
            return;
          }
  
          this.setState({  
              showWarningMessage: false ,
            });
    }

    render(){
        const Services=["Αστυνομία","ΕΚΑΒ","Πυροσβεστική","Λιμενικό"];
        const Levels=["Επίπεδο 1","Επίπεδο 2","Επίπεδο 3"];

        
        return(
            <div>
                <form onSubmit={this.submit_handler}>
                    <Grid container justify="center">
                            <Grid container className="title_grid">
                                <Grid item xs={5}>
                                    <div className="title_padding">
                                        <Typography align="right">Τίτλος Περιστατικού</Typography>
                                    </div>
                                </Grid>
                                <Grid item xs={6}>
                                    <div className="title_box">
                                        <TextField value={this.state.title} onChange={(e)=>{this.Handle_title(e)}} className="boxesStyle" align="left" id="outlined-basic" variant="outlined" size="medium"/>
                                    </div>
                                </Grid>
                            </Grid>

                            {/* Police Checkbox + Its button group */}
                            {Services.map((item,index_num)=>{
                                   
                                    return(
                                        
                                        <Grid container key={index_num} className="grid_cont" alignContent="center" justify="center">
                                            
                                        <div className="Synt_form_align">
                                                {/* {console.log("EDWREMALAKA")}
                                                {console.log(this.state.checkbox[index_num])} */}
                                            <FormControlLabel
                                                checked={!this.state.checkbox[index_num]}
                                                control={  <Checkbox  onClick={()=>this.handleVanishButtons(index_num)} color="primary"></Checkbox> }
                                                label={item}
                                                labelPlacement="end"
                                            />
                                        </div>

                                        <div className="button_group">
                                            <ToggleButtonGroup
                                                value={this.state.Level[index_num]}
                                                indexx={index_num}
                                                exclusive
                                                onChange={(e,value,index)=>this.handleLevelArray(e,value,index_num)}
                                                aria-label="text alignment"
                                                >
                                                {Levels.map((level,index)=>{
                                                    return(
                                                        <ToggleButton key={index} value={index} className="Level_buttons"  disabled={this.state.checkbox[index_num]} color="primary">{level}</ToggleButton>
                                                    );
                                                    

                                                })}
                                            </ToggleButtonGroup>
                                            {/* <ButtonGroup disabled={this.state.checkbox[index_num]} variant="contained" color="primary" aria-label="outlined primary button group"> */}
                                                {/* <Button>Επίπεδο 1</Button>
                                                <Button>Επίπεδο 2</Button>
                                                <Button>Επίπεδο 3</Button> */}
                                            {/* </ButtonGroup> */}
                                        </div>
                                    </Grid>
                                    );
                                    
                                
                                            })}

                            

                            {/* Location + Its box */}

                            <Grid container  className="incident_phone_grid">
                                <Grid container >
                                    <Grid item xs={5}>
                                        <div className="title_padding">
                                            <Typography align="right">Τοποθεσία X</Typography>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className="title_box">
                                            <TextField 
                                            value={this.state.location_X}
                                            className="boxesStyle"
                                            onChange={this.Handle_location_X}
                                            value={this.state.location_X}
                                            align="left" id="outlined-basic" 
                                            variant="outlined"
                                            size="medium"
                                            InputProps={{
                                                startAdornment: (
                                                <InputAdornment position="start">
                                                    <LocationOnIcon />
                                            </InputAdornment>
                                                ),
                                            }}
                                            />
                                        </div>
                                    </Grid>
                                </Grid>
                                <Grid container >
                                    <Grid item xs={5}>
                                        <div className="title_padding">
                                            <Typography align="right">Τοποθεσία Y</Typography>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className="title_box">
                                            <TextField 
                                            value={this.state.location_Y}
                                            className="boxesStyle"
                                            onChange={this.Handle_location_Y}
                                            value={this.state.location_Y}
                                            align="left" id="outlined-basic" 
                                            variant="outlined" 
                                            size="medium"
                                            InputProps={{
                                                startAdornment: (
                                                <InputAdornment position="start">
                                                    <LocationOnIcon />
                                            </InputAdornment>
                                                ),
                                            }}
                                            />
                                        </div>
                                    </Grid>
                                </Grid>
                                
                            </Grid>
                            
                            {/* PhoneNumber + Its box */}

                            <Grid container className="location_grid">
                                <Grid item xs={5}>
                                    <div className="phone_padding">
                                        <Typography align="right">Τηλέφωνο Επικοινωνίας</Typography>
                                    </div>
                                </Grid>
                                <Grid item xs={6}>
                                    <div className="phone_box">
                                        <TextField 
                                        value={this.state.phone}
                                        className="boxesStyle"
                                        onChange={this.Handle_phone}
                                        align="left" id="outlined-basic" 
                                        variant="outlined" 
                                        size="medium"
                                        InputProps={{
                                            startAdornment: (
                                            <InputAdornment position="start">
                                                <PhoneIcon />
                                            </InputAdornment>
                                            ),
                                            endAdornment: (
                                                <InputAdornment >
                                                    <IconButton onClick={this.handleWarningMessage}>
                                                        <InfoIcon></InfoIcon>
                                                    </IconButton>
                                                </InputAdornment>
                                            )
                                        }}
                                        />
                                        <Snackbar open={this.state.showWarningMessage} autoHideDuration={4000} onClose={this.handleCloseWarningSnackBar}>
                                        <Alert onClose={this.handleCloseWarningSnackBar} variant="filled" severity="warning">
                                            Πρέπει να αποτελείται από 10 ακριβώς ψηφία.
                                        </Alert>
                                    </Snackbar>
                                    </div>
                                </Grid>
                            </Grid>

                            


                            
                            {/* Submit button */}

                            <Grid container className="grid_submit_button" justify="center">
                                    <Button
                                        className="submit_button"
                                        variant="contained"
                                        color="primary"
                                        type="submit"
                                        disabled={this.handleSubmitButtonStatus()}
                                    >
                                        ΔΗΛΩΣΗ
                                    </Button>
                                    <Snackbar open={this.state.showSuccessSend} autoHideDuration={4000} onClose={this.handleCloseSnackBar}>
                                        <Alert onClose={this.handleCloseSnackBar} variant="filled" severity="success">
                                            Επιτυχής Δήλωση!
                                        </Alert>
                                    </Snackbar>
                            </Grid>

                        </Grid>
                    </form>
            </div>
        );
    }

}



export default Syntonisths_Form;
