<Grid container spacing={3} className="first_grid">
<Grid container direction="row" className="second_grid">

    {/* Περιστατικά Column */}

    <Grid container direction="column">
        <Grid item xs={3}>
                <div className="expansion_panel">
                    <Grid container direction="column">
                        <ExpansionPanel expanded={expanded === 'panel2'} onChange={handleChange2('panel2')}>
                            <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panel2bh-content"
                            id="panel2bh-header"
                            >
                                <Typography>Περιστατικό 0392</Typography>
                            </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <Grid container direction="column">
                                        <Grid item xs={9}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Τοποθεσία"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <LocationOnIcon></LocationOnIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Ημερομηνία"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <EventIcon></EventIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Πυροσβέστες"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <WhatshotIcon></WhatshotIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Εκαβίτες"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <LocalHospitalIcon></LocalHospitalIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                    </Grid>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </Grid>
                </div>
            </Grid>

            <Grid item xs={3}>
                <Grid container direction="column">
                        <ExpansionPanel expanded={expanded === 'panel1'} onChange={handleChange2('panel1')}>
                            <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panel1bh-content"
                            id="panel1bh-header"
                            >
                                <Typography>Περιστατικό 8125</Typography>
                            </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <Grid container direction="column">
                                        <Grid item xs={12}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Τοποθεσία"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <LocationOnIcon></LocationOnIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Ημερομηνία"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <EventIcon></EventIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Αστυνομικοί"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <SecurityIcon></SecurityIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <TextField
                                                className={classes.margin}
                                                id="input-with-icon-textfield"
                                                label="Λιμενικοί"
                                                InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <DirectionsBoatIcon></DirectionsBoatIcon>
                                                    </InputAdornment>
                                                ),
                                                }}
                                            >
                                            </TextField>
                                        </Grid>
                                    </Grid>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </Grid>
            </Grid>

    </Grid>
</Grid>
</Grid>


////////////////////////////////////////////////////////////////////////////////////////

import React from 'react';
import './syntonisths_forma.css';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FilledInput from '@material-ui/core/FilledInput';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Button from '@material-ui/core/Button';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import InputAdornment from '@material-ui/core/InputAdornment';
import PhoneIcon from '@material-ui/icons/Phone';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import PropTypes from 'prop-types';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import EventIcon from '@material-ui/icons/Event';
import WhatshotIcon from '@material-ui/icons/Whatshot';
import LocalHospitalIcon from '@material-ui/icons/LocalHospital';
import DirectionsBoatIcon from '@material-ui/icons/DirectionsBoat';
import SecurityIcon from '@material-ui/icons/Security';

import Container from '@material-ui/core/Container';
import CloseIcon from '@material-ui/icons/Close';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import ListItemText from '@material-ui/core/ListItemText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import PersonIcon from '@material-ui/icons/Person';
import ListItemIcon from '@material-ui/core/ListItemIcon';

const locations=['Σπίτι Μήτσιου'];

function TabPanel(props) {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box p={3}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }
  
TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}


const MyStyles = makeStyles ({
    tabsStyle : {
        fontSize:"120%",
        height:"120%",
        width:"120%",
        fontStyle:"italic",
        fontWeight:"bold",
    },
    boxesStyle : {
        [`& fieldset`]: {
            borderRadius: 20,
          },
    }
});

function SimpleDialog(props) {

    const classes = MyStyles();
    const { onClose, selectedValue, open } = props;
  
    const handleClose = () => {
      onClose(selectedValue);
    };
  
    const handleListItemClick = (value) => {
      onClose(value);
    };

    return (
        <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open}>
            <DialogTitle id="simple-dialog-title">Αλλαγή τρέχουσας τοποθεσίας</DialogTitle>
            
                {locations.map((location) => (
                // <ListItem onClick={() => handleListItemClick(location)} key={location}>
                    <List>
                        <ListItem>
                            <TextField className={classes.margin}
                                id="input-with-icon-textfield"
                                label="Παλιά Τοποθεσία"
                                defaultValue={location}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <LocationOnIcon></LocationOnIcon>
                                        </InputAdornment>
                                    ),
                                    readOnly : true,
                                }}
                            >
                            </TextField>
                        </ListItem>
                        <ListItem>
                            <TextField className={classes.margin}
                                id="input-with-icon-textfield"
                                label="Νέα Τοποθεσία"
                                InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <LocationOnIcon></LocationOnIcon>
                                    </InputAdornment>
                                ),
                                }}
                            >
                            </TextField> 
                        </ListItem>
                    </List>
                ))} 
            <DialogActions>
                <Button onClick={handleClose} color="primary">
                    Επιβεβαίωση Αλλαγής
                </Button>
            </DialogActions>       
        </Dialog>
    );
}

SimpleDialog.propTypes = {
    onClose: PropTypes.func.isRequired,
    open: PropTypes.bool.isRequired,
    selectedValue: PropTypes.string.isRequired,
};


export default function Syntonisths_Form() {
    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
      setValue(newValue);
    };

    const [expanded, setExpanded] = React.useState(false);

    const handleChange2 = (panel) => (event, isExpanded) => {
      setExpanded(isExpanded ? panel : false);
    };
  

    const classes = MyStyles();

    const [open, setOpen] = React.useState(false);
    const [selectedValue, setSelectedValue] = React.useState(locations[1]);
  
    const handleClickOpen = () => {
      setOpen(true);
    };
  
    const handleClose = (value) => {
      setOpen(false);
      setSelectedValue(value);
    };

    return (
        
        <div className="Syntonisths_Form">
            <Grid container spacing={3}>

                {/* The first 2 tabs */}

                <Grid item xs={12}>
                        <Tabs
                            value={value}
                            onChange={handleChange}
                            indicatorColor="inherit"
                            textColor="primary"
                            centered
                        >
                            <Tab className={classes.tabsStyle} label="ΝΕΑ ΔΗΛΩΣΗ ΠΕΡΙΣΤΑΤΙΚΟΥ"  {...a11yProps(0)}/>
                            <Tab className={classes.tabsStyle} label="ΕΝΕΡΓΑ ΠΕΡΙΣΤΑΤΙΚΑ"{...a11yProps(1)} />
                        </Tabs>
                </Grid>

                {/* Tab : Νέα Δήλωση Περιστατικού  */}

                <TabPanel value={value} index={0}>
                    <Grid container justify="center">
                        <Grid container className="title_grid">
                            <Grid item xs={5}>
                                <div className="title_padding">
                                    <Typography align="right">Τίτλος Περιστατικού</Typography>
                                </div>
                            </Grid>
                            <Grid item xs={6}>
                                <div className="title_box">
                                    <TextField className={classes.boxesStyle} align="left" id="outlined-basic" variant="outlined" size="medium"/>
                                </div>
                            </Grid>
                        </Grid>

                        {/* Police Checkbox + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox color="primary"></Checkbox> }
                                    label="Αστυνομία"
                                    labelPlacement="end"
                                />
                            </div>
                            <div className="button_group">
                                <ButtonGroup variant="contained" color="primary" aria-label="outlined primary button group">
                                    <Button>Επίπεδο 1</Button>
                                    <Button>Επίπεδο 2</Button>
                                    <Button>Επίπεδο 3</Button>
                                </ButtonGroup>
                            </div>
                        </Grid>

                        {/* EKAB Checkbox + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox color="primary"></Checkbox> }
                                    label="ΕΚΑΒ"
                                    labelPlacement="end"
                                />
                            </div>
                            <ButtonGroup variant="contained" color="primary" aria-label="outlined primary button group">
                                <Button>Επίπεδο 1</Button>
                                <Button>Επίπεδο 2</Button>
                                <Button>Επίπεδο 3</Button>
                            </ButtonGroup>
                        </Grid>

                        {/* Firefighters Checkbox + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox color="primary"></Checkbox> }
                                    label="Πυροσβεστική"
                                    labelPlacement="end"
                                />
                            </div>
                            <ButtonGroup variant="contained" color="primary" aria-label="outlined primary button group">
                                <Button>Επίπεδο 1</Button>
                                <Button>Επίπεδο 2</Button>
                                <Button>Επίπεδο 3</Button>
                            </ButtonGroup>
                        </Grid>

                        {/* Port authority + Its button group */}

                        <Grid container className="grid_cont" alignContent="center" justify="center">
                            <div className="Synt_form_align">
                                <FormControlLabel
                                    control={  <Checkbox color="primary"></Checkbox> }
                                    label="Λιμενικό"
                                    labelPlacement="end"
                                />
                            </div>
                            <ButtonGroup variant="contained" color="primary" aria-label="outlined primary button group">
                                <Button>Επίπεδο 1</Button>
                                <Button>Επίπεδο 2</Button>
                                <Button>Επίπεδο 3</Button>
                            </ButtonGroup>
                        </Grid>

                        {/* Location + Its box */}

                        <Grid container className="incident_phone_grid">
                            <Grid item xs={5}>
                                <div className="title_padding">
                                    <Typography align="right">Τοποθεσία Συμβάντος</Typography>
                                </div>
                            </Grid>
                            <Grid item xs={6}>
                                <div className="title_box">
                                    <TextField 
                                    className={classes.boxesStyle} 
                                    align="left" id="outlined-basic" 
                                    variant="outlined" 
                                    size="medium"
                                    InputProps={{
                                        startAdornment: (
                                        <InputAdornment position="start">
                                            <LocationOnIcon />
                                    </InputAdornment>
                                        ),
                                    }}
                                    />
                                </div>
                            </Grid>
                        </Grid>
                        
                        {/* PhoneNumber + Its box */}

                        <Grid container className="location_grid">
                            <Grid item xs={5}>
                                <div className="phone_padding">
                                    <Typography align="right">Τηλέφωνο Επικοινωνίας</Typography>
                                </div>
                            </Grid>
                            <Grid item xs={6}>
                                <div className="phone_box">
                                    <TextField 
                                    className={classes.boxesStyle} 
                                    align="left" id="outlined-basic" 
                                    variant="outlined" 
                                    size="medium"
                                    InputProps={{
                                        startAdornment: (
                                        <InputAdornment position="start">
                                            <PhoneIcon />
                                    </InputAdornment>
                                        ),
                                    }}
                                    />
                                </div>
                            </Grid>
                        </Grid>
                        
                        {/* Submit button */}

                        <Grid container className="grid_submit_button" justify="center">
                                <Button
                                    className="submit_button"
                                    variant="contained"
                                    color="primary"
                                >
                                    ΔΗΛΩΣΗ
                                </Button>
                        </Grid>

                    </Grid>

                </TabPanel>

                {/* Tab : ΕΝΕΡΓΑ ΠΕΡΙΣΤΑΤΙΚΑ */}

                <TabPanel className="existing_incidents_tabpanel" value={value} index={1}>
                    <Grid container spacing={3} className="open_incidents_gr">

                        {/* Περιστατικά Columns */}

                        <Grid item xs={2} class="incidents_Col"> {/* Για το column με τα περιστατικά */}
                            <Grid container direction="column" spacing={12}>

                                {/* Πρώτο Περιστατικό */}

                                <ExpansionPanel expanded={expanded === 'panel2'} onChange={handleChange2('panel2')}>
                                    <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panel2bh-content"
                                    id="panel2bh-header"
                                    >
                                        <Typography className="the_incident_title">Περιστατικό 0392</Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>
                                        <Grid container direction="column">
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Τοποθεσία"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <LocationOnIcon></LocationOnIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Ημερομηνία"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <EventIcon></EventIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Πυροσβέστες"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <WhatshotIcon></WhatshotIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Εκαβίτες"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <LocalHospitalIcon></LocalHospitalIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                        </Grid>
                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                {/* Δεύτερο Περιστατικό */}
                                
                                <ExpansionPanel expanded={expanded === 'panel1'} onChange={handleChange2('panel1')}>
                                    <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panel1bh-content"
                                    id="panel1bh-header"
                                    >
                                        <Typography className="the_incident_title">Περιστατικό 8125</Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>
                                        <Grid container direction="column">
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Τοποθεσία"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <LocationOnIcon></LocationOnIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Ημερομηνία"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <EventIcon></EventIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Αστυνομικοί"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <SecurityIcon></SecurityIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                            <Grid item xs={12}>
                                                <TextField
                                                    className={classes.margin}
                                                    id="input-with-icon-textfield"
                                                    label="Λιμενικοί"
                                                    InputProps={{
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <DirectionsBoatIcon></DirectionsBoatIcon>
                                                        </InputAdornment>
                                                    ),
                                                    }}
                                                >
                                                </TextField>
                                            </Grid>
                                        </Grid>
                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                {/* Ελεύθερος χώρος για περισσότερα περιστατικά */}


                                <Paper>Περιστατικό 0110</Paper>
                                <Paper>Περιστατικό 0222</Paper>
                                <Paper>Περιστατικό 0333</Paper>
                                <Paper>Περιστατικό 0444</Paper>

                            </Grid>
                        </Grid> {/* End of the space allocated for the incidents column */}

                        <Grid item xs={9} className="open_incident_info"> {/* Χώρος για τα πράγματα δεξία από το column-Στο ίδιο ύψος */ }
                            <Grid container>
                                <Grid item xs={3}>
                                    <Typography>Περιστατικό 0392 (31/03/2020)</Typography>
                                </Grid>
                                <Grid item xs={9}>
                                    <Grid container justify="flex-end">
                                        <div className="close_incident"> {/* This class doesnt work.Idk why.. */}
                                            <Button  className="fuckyou"variant="contained" startIcon={<CloseIcon />}>
                                                ΚΛΕΙΣΙΜΟ ΠΕΡΙΣΤΑΤΙΚΟΥ
                                            </Button>
                                        </div>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={3}>
                                    <TextField
                                        className={classes.margin}
                                        id="input-with-icon-textfield"
                                        label="Τοποθεσία"
                                        defaultValue="Χρυσοστόμου Σμύρνης 12Β"
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <LocationOnIcon></LocationOnIcon>
                                                </InputAdornment>
                                            ),
                                            readOnly : true,
                                        }}
                                    >
                                    </TextField>
                                </Grid>
                                <Grid item xs={6} className="change_location">
                                    <Button variant="outlined" color="primary" onClick={handleClickOpen}>
                                        Αλλαγή τοποθεσίας
                                    </Button>
                                    <SimpleDialog selectedValue={selectedValue} open={open} onClose={handleClose} />
                                </Grid>
                                <Grid item xs={7}>
                                    <TextField
                                        className={classes.margin}
                                        id="input-with-icon-textfield"
                                        label="Τηλέφωνο"
                                        defaultValue="6984002910"
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <PhoneIcon></PhoneIcon>
                                                </InputAdornment>
                                            ),
                                            readOnly : true,
                                        }}
                                    >
                                    </TextField>
                                </Grid>
                            </Grid>
                            <Grid container className="services_titles" direction="row">
                                <Grid item xs={3}>
                                    <Typography>ΕΚΑΒιτες</Typography>
                                </Grid>
                                <Grid item xs={3}>
                                    <Typography>Πυροσβέστες</Typography>
                                </Grid>
                                <Grid item xs={3}>
                                    <Typography>Αστυνομικοί</Typography>
                                </Grid>
                                <Grid item xs={3}>
                                    <Typography>Λιμενικοί</Typography>
                                </Grid>
                            </Grid>
                            
                        </Grid>
                    </Grid>
                   
                </TabPanel>
            </Grid>
        </div>
    );
}

//////////////////////////////////////////////////////
<Grid item xs={9} className="open_incident_info"> {/* Χώρος για τα πράγματα δεξία από το column-Στο ίδιο ύψος */ }
<Grid container>
    <Grid item xs={3}>
        <Typography>Περιστατικό 0392 (31/03/2020)</Typography>
    </Grid>
    <Grid item xs={9}>
        <Grid container justify="flex-end">
            <div className="close_incident"> {/* This class doesnt work.Idk why.. */}
                <Button  className="fuckyou"variant="contained" startIcon={<CloseIcon />}>
                    ΚΛΕΙΣΙΜΟ ΠΕΡΙΣΤΑΤΙΚΟΥ
                </Button>
            </div>
        </Grid>
    </Grid>
</Grid>
<Grid container>
    <Grid item xs={3}>
        <TextField
            className={classes.margin}
            id="input-with-icon-textfield"
            label="Τοποθεσία"
            defaultValue="Χρυσοστόμου Σμύρνης 12Β"
            InputProps={{
                startAdornment: (
                    <InputAdornment position="start">
                        <LocationOnIcon></LocationOnIcon>
                    </InputAdornment>
                ),
                readOnly : true,
            }}
        >
        </TextField>
    </Grid>
    <Grid item xs={6} className="change_location">
        <Button variant="outlined" color="primary" onClick={handleClickOpen}>
            Αλλαγή τοποθεσίας
        </Button>
        <SimpleDialog selectedValue={selectedValue} open={open} onClose={handleClose} />
    </Grid>
    <Grid item xs={7}>
        <TextField
            className={classes.margin}
            id="input-with-icon-textfield"
            label="Τηλέφωνο"
            defaultValue="6984002910"
            InputProps={{
                startAdornment: (
                    <InputAdornment position="start">
                        <PhoneIcon></PhoneIcon>
                    </InputAdornment>
                ),
                readOnly : true,
            }}
        >
        </TextField>
    </Grid>
</Grid>
<Grid container className="services_titles" direction="row">
    <Grid item xs={3}>
        <Typography>ΕΚΑΒιτες</Typography>
    </Grid>
    <Grid item xs={3}>
        <Typography>Πυροσβέστες</Typography>
    </Grid>
    <Grid item xs={3}>
        <Typography>Αστυνομικοί</Typography>
    </Grid>
    <Grid item xs={3}>
        <Typography>Λιμενικοί</Typography>
    </Grid>
</Grid>

</Grid>