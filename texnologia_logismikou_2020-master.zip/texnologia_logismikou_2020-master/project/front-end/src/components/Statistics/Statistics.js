import React ,{Component} from 'react';
import CanvasJSReact from '../../lib/canvasjs.react';
import Date_Time from '../../lib/Date';
//var CanvasJSReact = require('./canvasjs.react');
var CanvasJS = CanvasJSReact.CanvasJS;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;
 
class Statistics extends Component {
	constructor(props){
		super(props);

		this.state={
			totals_:[],
			incidents:[]
		};
		var all_totals;

		this.produce_Datapoints=this.produce_Datapoints.bind(this);
		this.handle_show_diagram=this.handle_show_diagram.bind(this);
		this.show_deaths_injuries=this.show_deaths_injuries.bind(this);
		// this.fetchIncidents=this.fetchIncidents.bind(this);
		// this.show_all_info=this.show_all_info.bind(this);
	}	
	
	produce_Datapoints=(all_totals,options)=>{
		// e.preventDefault();
			var sorted_dates=this.props.prev_state.List_of_incidens.slice().sort(function(a,b){
				// Turn your strings into dates, and then subtract them
				// to get a value that is either negative, positive, or zero.
				
				return new Date(a.date)- new Date(b.date) ;
			});  
			// console.log("Sorted arrays: "+sorted_dates[0].name);
			// console.log("Sorted arrays: "+sorted_dates[1].name);
			// console.log("Sorted arrays: "+sorted_dates[2].name);
			
			var i=0;
			var flag=true;
			// var total = new Array();
			sorted_dates.map((item,index_num)=>{
				console.log("ITEM= "+item.title);
				var inc_date=new Date(item.date);
				var level=item.unitsDeployed/2;
				var level_checker=false;
                if(this.props.prev_state.Level_1){
                    if(level===1){
                        level_checker=true;
                    }
                }
                if(this.props.prev_state.Level_2){
                    if(level===2){
						level_checker=true;
                    }
                }
                if(this.props.prev_state.Level_3){
                    if(level===3){
						level_checker=true;
                    }
                }
				if(inc_date>=this.props.prev_state.Filter_date_from && inc_date<=this.props.prev_state.Filter_date_to &&  level_checker){
					if(flag){
						all_totals.total.push({ids:[],deaths:0,units:0,injuries:0,incidents:0,date:inc_date.toISOString().slice(0,10)});
						flag=false;
					}
					if(all_totals.total[i].date===inc_date.toISOString().slice(0,10)){
						// all_totals.total[i].ids.push(item);
						all_totals.total[i].deaths=all_totals.total[i].deaths+item.casualties;
						all_totals.total[i].units=all_totals.total[i].units+item.unitsDeployed;
						all_totals.total[i].injuries=all_totals.total[i].injuries+item.injuries;
						all_totals.total[i].incidents++;
					}
					else{
						// console.log("MPHKEEEEEE "+index_num);
						i++;
						
						all_totals.total.push({deaths:0,units:0,injuries:0,incidents:0,date:inc_date.toISOString().slice(0,10)});
						// all_totals.total[i].ids.push(item);
						all_totals.total[i].deaths=all_totals.total[i].deaths+item.casualties;
						all_totals.total[i].units=all_totals.total[i].units+item.unitsDeployed;
						all_totals.total[i].injuries=all_totals.total[i].injuries+item.injuries;
						all_totals.total[i].incidents++;
						// all_totals.total[i].deaths=all_totals.total[i].deaths+item.deaths;
						// all_totals.total[i].injuries=all_totals.total[i].injuries+item.injuries;
						// all_totals.total[i].incidents++;
					}
				}
				
				
			});
			
			var joined=options;
			joined.data[0].dataPoints=[];			
			// joined.data[0].click=
			all_totals.total.map((item,index_num)=>{
				// console.log(item);
				joined.data[0].dataPoints.push({y:item.incidents,label:item.date});
				// joined.data[0].dataPoints[index_num].label=item.date;
			});

			// this.setState({
				
			// 	totals_:all_totals.total
			// });

		// return total;
		// return console.log("MPIKE OLA KALA");
	}
	

	handle_show_diagram=(all_totals,options2)=>{
		var total=all_totals.total;
		if(this.props.prev_state.deaths_checked || this.props.prev_state.injuries_checked || this.props.prev_state.units_checked){
			// console.log("HERE malakaaa "+total);
			if(this.props.prev_state.deaths_checked){
				var joined=options2;
				// console.log("MPIKE 1 ");
				// joined.data[0].dataPoints=[];
				total.map((item,index_num)=>{
					// console.log(item);
					options2.data[0].dataPoints.push({y:item.deaths,label:item.date});
					// joined.data[0].dataPoints[index_num].label=item.date;
				});
				
			}
			if(this.props.prev_state.injuries_checked){
				var joined=options2;
				// console.log("MPIKE 2 ");
				// joined.data[0].dataPoints=[];
				total.map((item,index_num)=>{
					// console.log(item);
					options2.data[1].dataPoints.push({y:item.injuries,label:item.date});
					// joined.data[0].dataPoints[index_num].label=item.date;
				});
				
			}

			if(this.props.prev_state.units_checked){
				var joined=options2;
				console.log("MPIKE 3");
				// joined.data[0].dataPoints=[];
				total.map((item,index_num)=>{
					console.log(item);
					options2.data[2].dataPoints.push({y:item.units,label:item.date});
					// joined.data[0].dataPoints[index_num].label=item.date;
				});
				
			}
			
			// return(<CanvasJSChart options = {options2} 
			// 	/* onRef={ref => this.chart = ref} */
			// />);
		}
	}

	// show_all_info=()=>{
	// 	if(this.props.prev_state.all_info){
	// 		let all_inc=this.fetchIncidents();
	// 		console.log(all_inc);
	// 	}
		
	// }

	// fetchReports = async () => {
	// 	const data = await fetch('http://localhost:3001/control-center/api/reports', {
	// 	  method: 'GET',
	// 	  headers: {
	// 		'Accept': 'application/json',
	// 		'Content-Type': 'application/json',
	// 		'Authorization': 'Bearer ' + this.props.detail.token
	// 	  }
	// 	});
	// 	if (data.status === 200) {
	
	// 	  const incidentData = await data.json();
	// 	  const liveIncidents = [];
		  
	// 		this.all_totals.total.forEach((total,index_num)=>{
	// 			console.log("length "+total.ids.length);
	// 			console.log(total);
	// 			if(total.ids.length> 0){
	// 				console.log("EISXORHSA");
	// 				liveIncidents.push([]);
	// 			}
	// 			incidentData.forEach((incident)=>{
	// 			total.ids.forEach((id) => {
	// 				if(id.incidentId===incident._id){
	// 					if (!id.isOpen) {
	// 						liveIncidents[index_num].push(incident);
	// 					// fetchReports(); //fetch all the reports for the agency
	// 					// fetchFormalReport(); //get the formal report 
	// 					}
	// 				}
					
	// 				// this.setState({
	// 				// 	incidents:liveIncidents
	// 				// });
	// 			  });	
	// 		  })
	// 	  })
	// 	  console.log(this.all_totals);
	// 	  console.log(liveIncidents);
	// 	  return liveIncidents;
	// 	} else {
			
	// 	  console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
	// 	  return 0;
	// 	   }
	//   }

	// fetchIncidents = async () => {
	// 	const data = await fetch('http://localhost:3001/control-center/api/incidents', {
	// 	  method: 'GET',
	// 	  headers: {
	// 		'Accept': 'application/json',
	// 		'Content-Type': 'application/json',
	// 		'Authorization': 'Bearer ' + this.props.detail.token
	// 	  }
	// 	});
	// 	if (data.status === 200) {
	
	// 	  const incidentData = await data.json();
	// 	  const liveIncidents = [];
		  
	// 		this.all_totals.total.forEach((total,index_num)=>{
	// 			console.log("length "+total.ids.length);
	// 			console.log(total);
	// 			if(total.ids.length> 0){
	// 				console.log("EISXORHSA");
	// 				liveIncidents.push([]);
	// 			}
	// 			incidentData.forEach((incident)=>{
	// 			total.ids.forEach((id) => {
	// 				if(id.incidentId===incident._id){
	// 					if (!id.isOpen) {
	// 						liveIncidents[index_num].push(incident);
	// 					// fetchReports(); //fetch all the reports for the agency
	// 					// fetchFormalReport(); //get the formal report 
	// 					}
	// 				}
					
	// 				// this.setState({
	// 				// 	incidents:liveIncidents
	// 				// });
	// 			  });	
	// 		  })
	// 	  })
	// 	  console.log(this.all_totals);
	// 	  console.log(liveIncidents);
	// 	  return liveIncidents;
	// 	} else {
			
	// 	  console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
	// 	  return 0;
	// 	   }
	//   }

	show_deaths_injuries=(options2)=>{
		if(this.props.prev_state.deaths_checked || this.props.prev_state.injuries_checked || this.props.prev_state.units_checked){
			// console.log(options2.data);
			options2.data[0].dataPoints.map((item,index_num)=>{
				// console.log("OPTION2-0= "+item.y+"==="+item.label);
			});
			options2.data[1].dataPoints.map((item,index_num)=>{
				// console.log("OPTION2-1= "+item.y+"==="+item.label);
			});
			// console.log("OPTION2-0= "+options2.data[0].dataPoints);
			// console.log("OPTION2-1= "+options2.data[1].dataPoints);
			return(<CanvasJSChart options = {options2} 
				/* onRef={ref => this.chart = ref} */
			/>);
		}
		else{
			return null;
		}	
	}
	

	render() {
		// const all_total=this.produce_Datapoints;
		this.all_totals={total:[]};
		
		var options={
			animationEnabled: true,
			exportEnabled: true,
			theme: "light1", // "light1", "dark1", "dark2"
			title:{
				
			},
			data: [{
				type: "column",
				indexLabel: "{label}: {y}",		
				startAngle: -90,
				dataPoints: []
			},
			      
				
			]
		};
		var options2= {
			animationEnabled: true,	
			exportEnabled: true,
			title:{
				
			},
			// axisY : {
			// 	title: "Αριθμός Ανθρώπων",
			// 	includeZero: false
			// },
			toolTip: {
				shared: true
			},
			data: [{
				type: "spline",
				name: "Θανάτοι",
				showInLegend: true,
				dataPoints: []
			},
			{
				type: "spline",
				name: "Τραυματίες",
				showInLegend: true,
				dataPoints: []
			},
			{
				type: "spline",
				name: "Όργανα Υπηρεσίας",
				showInLegend: true,
				dataPoints: []
			}]
		};
		// console.log(this.props.prev_state.deaths_checked );
		// console.log( this.props.prev_state.injuries_checked);		
		return (
		<div>
			{/* {console.log("STATISTICS")} */}
			{this.produce_Datapoints(this.all_totals,options)}
			{/* {console.log("ALL_TOTALS= "+this.all_totals.total)}
			{console.log(this.all_totals.total)} */}
			<CanvasJSChart options={options} 
				/* onRef={ref => this.chart = ref} */
			/>
			{this.handle_show_diagram(this.all_totals,options2)}
			{/* {this.show_all_info()} */}
			{this.show_deaths_injuries(options2)}
			{/*You can get reference to the chart instance as shown above using onRef. This allows you to access all chart properties and methods*/}
		</div>
		);
	}
}
 
export default Statistics;