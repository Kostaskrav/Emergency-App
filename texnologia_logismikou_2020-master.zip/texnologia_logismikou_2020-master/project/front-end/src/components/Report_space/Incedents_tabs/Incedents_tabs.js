import React ,{Component} from 'react';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Alert from '@material-ui/lab/Alert';
import Snackbar from '@material-ui/core/Snackbar';
import Pop_ensure_send from '../Pop_ensure_send';


import './Incedents_tabs.css';



function TabPanel(props) {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`scrollable-auto-tabpanel-${index}`}
        aria-labelledby={`scrollable-auto-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box p={3}>
            <Typography component={'div'}>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }
  
  TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
  };

function a11yProps(index) {
    return {
      id: `scrollable-auto-tab-${index}`,
      'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
  }

  

class Incedents_tabs extends Component{

    constructor(props){
        super(props);

        this.state={
            value:0,
            showSuccessSend:false,
            showPopup: false ,
            comments_text:[]
        }

        // console.log(this.props)


        this.handleClickOpen=this.handleClickOpen.bind(this);
        this.change_report_text=this.change_report_text.bind(this);
        this.submit_handler=this.submit_handler.bind(this);
        this.handleOpenPopUp=this.handleOpenPopUp.bind(this);
        this.handleSuccessSend=this.handleSuccessSend.bind(this);
        this.submit_Pop_up_check=this.submit_Pop_up_check.bind(this);
        this.patchReport=this.patchReport.bind(this);
        this.handleShow=this.handleShow.bind(this);

    }

    handleClickOpen = (event,newValue) => {
        this.setState({  
            value: newValue 
        });
      };

      change_report_text=(event,index)=>{        
      
        let newVal = event.target.value;
        var joined=this.state.comments_text;
        joined[this.state.value]=newVal;    
          this.setState({
            comments_text:joined
          });
          
      }

      submit_Pop_up_check=(event)=>{
        event.preventDefault();
        this.setState({  
          showPopup:true, 
        });
      }

      submit_handler=(event,index_num)=>{
        event.preventDefault();
        if(this.state.comments_text[index_num]==="" || this.state.comments_text[index_num]===null){
          console.log("MPHKAAA");
          this.setState({  
            showPopup: false,
          });
          alert("To Report ήταν κενό!");
          return null;
        }
        
        //add the comments the user added to the report ! 
        this.patchReport(index_num);
        
        this.props.change_total_incedents(index_num);

            
        this.setState({  
          showPopup: false,
          showSuccessSend: true ,
          value : 0,
          
        });    
        
      }

      handleOpenPopUp=()=>{
        this.setState({  
          showPopup: false  
        });

      }

      init_comments_text(index_num){
        if(this.state.comments_text[index_num]== null){
          var joined=this.state.comments_text;
          joined[index_num]="";
          this.setState({
            comments_text:joined
          })
        }
      }

     patchReport=async(index_num)=>{
       let id = "";
        await this.props.state.every_report.map((e)=>{
        // console.log(e)
        e.map((item)=>{
         if(item.writer === this.props.uId && item.incId === this.props.state.total_incedents[index_num]._id ){
           console.log("found the report");
           id = item.id;
         }
        })         
      })
      const data = await fetch('http://localhost:3001/control-center/api/reports/' + id , {
        method: 'PATCH',
        headers: { 
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + this.props.token
        },
        body: JSON.stringify({
          comments : this.state.comments_text[index_num],
        })
      });
      
      if(data.status === 200){
        // console.log("updated");
        const data_obj=await data.json();
        // console.log(data_obj);
        // if(data_obj.hasOwnProperty('formal_report_id')){
        //   console.log("HERE "+data_obj.formal_report_id);
        // }
        var joined=this.state.comments_text;
        joined.splice(index_num,1);
        this.setState({
          comments_text:joined
        })
      
      }else{
        console.log("Error Code : " + data.status + "\nError Message : " + data.statusText);
      }
      // fetch('http://localhost:3001/control-center/api/reports/' + id , {
      //   method: 'PATCH',
      //   headers: { 
      //     'Accept': 'application/json',
      //     'Content-Type': 'application/json',
      //     'Authorization': 'Bearer ' + this.props.token
      //   },
      //   body: JSON.stringify({
      //     comments : this.state.reportUpdate
      //   })
      // }).then(response => {
      //   if (response.ok) {
      //     response.json().then(json => {
      //       console.log(json);
      //     });
      //   }
      // });
     }

    

      handleSuccessSend=()=>{
        this.setState({  
          showSuccessSend: true  
        });
      }
      handleShow=()=>{
        if(this.state.showPopup){
          return(<Pop_ensure_send report_name={this.props.state.total_incedents[this.state.value].title} tab_num={this.state.value} showSuccessSend={this.submit_handler} closePopup={this.handleOpenPopUp}></Pop_ensure_send>);
        }
        else{
          return null;
        }
      }

    render(){     
      const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
          return;
        }

        this.setState({  
          showSuccessSend: false 
        });
      };
        return(
            <div>
                <AppBar position="static" color="default">
                    <Tabs
                    value={this.state.value}
                    onChange={this.handleClickOpen}
                    indicatorColor="primary"
                    textColor="primary"
                    variant="scrollable"
                    scrollButtons="auto"
                    aria-label="scrollable auto tabs example"
                    >
                    {this.props.state.total_incedents.map((item,index_num) =>
                        
                        <Tab key={index_num}
                       
                         label={item.title} 
                         {...a11yProps(index_num)} />
                        
                    )}
                                        
                    </Tabs>
                </AppBar>
                
                {this.props.state.total_incedents.map((item,index_num)=>
                    <TabPanel key={index_num} value={this.state.value} index={index_num}>

                        {/* //edo einai ta report tabs pou eipame pos tha mpoune sto formal report ! */}
                        {/* <Report_tabs reports={this.props.state.every_report[index_num]}></Report_tabs> */}


                        {this.init_comments_text(index_num)}
                        
                        <form onSubmit={(event)=>{this.submit_Pop_up_check(event,this.state.value)}}>
                        
                          
                                
                          <TextField
                            id="standard-disabled"
                            multiline
                            fullWidth
                            rows={5}
                            rowsMax={10}
                            variant="outlined"
                            value={this.state.comments_text[this.state.value]}
                            onChange={(e)=>{ this.change_report_text(e,this.state.value)}}
                            />
                            <Button
                              variant="contained"
                              color="primary"
                              type="submit"
                            >
                              Αποστολή
                            </Button>
                        </form>
                    </TabPanel>
                )}
                <Snackbar open={this.state.showSuccessSend} autoHideDuration={6000} onClose={handleClose}>
                <Alert onClose={handleClose} severity="success">
                  To Report εστάλει επιτυχώς!
                </Alert>
                </Snackbar>
                {this.handleShow()}
                {/* {this.state.showPopup ?
                  <Pop_ensure_send tab_num={this.state.value} showSuccessSend={this.submit_handler} closePopup={this.handleOpenPopUp}></Pop_ensure_send>
                  : null
                } */}
            </div>
        );
    }

}



export default Incedents_tabs;