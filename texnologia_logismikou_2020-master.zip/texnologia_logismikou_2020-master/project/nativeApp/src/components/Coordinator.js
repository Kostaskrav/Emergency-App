import React, { useState ,useEffect, useLayoutEffect} from 'react';
import { StyleSheet, Text, View,SafeAreaView,FlatList,RefreshControl } from 'react-native';
import { Icon } from 'react-native-elements';
import Incident from './Incident';
import Logout from './Logout';
import ip from './ipInput.json';



export default function Coordinator(props) { 
    
    const [listOfIncidents , setListOfIncidents] = useState([]);
    const [refreshing, setRefreshing] = React.useState(false);


    const fetchIncidents = async () => {
        const data = await fetch('http://'+ ip.userIp +':3001/control-center/api/incidents', {
          method: 'GET',
          headers: { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + props.route.params.detail.token
          }
        });
        if(data.status===200){
    
          const incidentData = await data.json();
          const liveIncidents = [];
          incidentData.forEach(incident => {
              if(incident.isOpen){
                  liveIncidents.push(incident);
              }
          });         
          if (JSON.stringify(listOfIncidents) !== JSON.stringify(liveIncidents)) {
            setListOfIncidents([...liveIncidents]);
          }
        }else{
         console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
        
        }
      }

      const onRefresh = React.useCallback(async () => {
        setRefreshing(true);
        fetchIncidents();
        setRefreshing(false);
      }, [refreshing]);

      useEffect(() => {
          fetchIncidents();
      },[]);

      useLayoutEffect(() => {
        props.navigation.setOptions({
          headerRight: () => (
            <Logout {...props} token={props.route.params.detail.token} />
          ),
        });
      }, []);
    
   
    
    return(
        
      
            <SafeAreaView style={styles.container}
            >
              <View>
                {listOfIncidents.length > 0  
                ? <FlatList
                style={Antstyles.Texts}
                data={listOfIncidents}
                renderItem={ ({item}) => (<Incident isHead={false} item={item}/>)} 
                keyExtractor={item => item._id}
                refreshControl={
                  <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
                }
                showsVerticalScrollIndicator={false}
            /> : <Text style={{display: 'flex', fontSize: 80, justifyContent:'center', alignItems:'center', height: 200}}>There are no live incidents</Text> }
                </View>
            </SafeAreaView>
);}

const styles = StyleSheet.create({
    item: {
        backgroundColor: '#fff',
        paddingHorizontal: 25,
        paddingVertical: 10,
        borderRadius: 10,
        marginHorizontal: 10,
        marginVertical: 5
    },
    header: {
        fontSize: 25,
        color: '#000'
    },
    subHeader: {
        fontSize: 15,
        fontStyle: 'italic',
        color: 'grey'
    }
  });

const Antstyles = StyleSheet.create ({
  Texts: {
    backgroundColor:"beige",
  }
})