import React, { useState } from "react";
import { Alert, Modal, StyleSheet, Text, TouchableHighlight,ScrollView, View } from "react-native";
import { Ionicons } from '@expo/vector-icons';


const Px = (props) => {
  const [modalVisible, setModalVisible] = useState(false);

  const modalFun = () => {
    if(props.choose === "live"){
      return(props.liveIncident.hasOwnProperty("_id") ? <Text style={styles.modalText}>{props.incident}</Text> : <Text style={styles.modalText}>Δεν υπάρχει ενεργό περιστατικό</Text>  );
    }
    else if (props.choose === "incidents"){
      return(props.incidents.length > 0 ?  <Text style={styles.modalText}>{props.incidents}</Text> : <Text style={styles.modalText}>Δεν υπάρχουν αναφορές προς κατάθεση</Text> );
    }
    else if(props.choose === "reports"){
      const reports = [];
        props.reports.map((item)=>{
            if(item.incidentId === props.item._id){
            reports.push("[ID :" + item._id +  "\nΤίτλος : " + item.title + "\nID-Χρήστη : " + item.userId  +"\nID-Περιστατικού : " + item.incidentId + "\Σχόλια : " + item.comments  + "\nΕίναι το περιστατικό ανοιχτό : " + item.isOpen + "]\n");
            }
        });
        if(reports.length === 0){
          return (<Text style={styles.modalText}>Δεν έχουν κατατεθεί αναφορές</Text>);
        }
        else{
            return (<Text style={styles.modalText}>{reports}</Text>);
        }
    }else if(props.choose === "fr"){
      if(props.fr.hasOwnProperty("_id")) {
        const line =  "ΛΕΠΤΟΜΕΡΙΕΣ ΓΙΑ ΤΗΝ ΕΠΙΣΗΜΗ ΑΝΑΦΟΡΑ ΜΕ ID :" + props.fr._id + "\nΤίτλος : " + props.fr.title + "\nID-Χρήστη : " + props.fr.userId + "\nID-Περιστατικού : " + props.fr.incidentId + "\nΗμερομηνία : " + props.fr.date + "\nΤραυματισμοί : " + props.fr.injuries + "\n" + props.fr.casualties + "\nΑριθμός Μονάδων" + props.fr.unitsDeployed + "\nΣχόλια" + props.fr.comments + "\n";
      return(<Text style={styles.modalText}>{line}</Text>);

    }else{
        return(<Text style={styles.modalText}>Δεν έχει κατατεθεί επίσημη αναφορά</Text>);
    }
    }
    else if(props.choose === "users"){
        const users = [];
        props.item.users[props.agencyId].map((user)=>{
           const line =  "\n\n\nΌνομα:" + user.firstName + "\nΕπίθετο : " + user.lastName + "\nID-Χρήστη : " + user._id + "\nEmail : " + user.email ;
           users.push(line);
        });
        return(users.length > 0 ?  <Text style={styles.modalText}>{users}</Text> : <Text style={styles.modalText}>Δεν υπάρχουν όργανα στο περιστατικό</Text> );
    }
    else{
      const line = "ΛΕΠΤΟΜΕΡΙΕΣ ΓΙΑ ΤΟ ΠΕΡΙΣΤΑΤΙΚΟ ΜΕ ID :" + props.item._id + "\n\nΤίτλος : " + props.item.title + "\nΗμερομηνία : " + props.item.startDate + "\nLat : " + props.item.x + "\nLon : " + props.item.y + "\nΤηλέφωνο : " + props.item.telephone + "\n";
      return(<Text style={styles.modalText}>{line}</Text>);
    }
  }

  return (
    <View style={styles.centeredView}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
          <ScrollView showsVerticalScrollIndicator={false}>
           {modalFun()}
          </ScrollView>

            <TouchableHighlight
              style={{ ...styles.openButton, backgroundColor: "#c9c943" }}
              onPress={() => {
                setModalVisible(!modalVisible);
              }}
            >
              <Text style={styles.textStyle}>OK</Text>
            </TouchableHighlight>
          </View>
        </View>
      </Modal>
      {props.coord ?  
     <Ionicons name="md-arrow-round-forward" 
      style={styles.roundIcon}
      onPress={() => {
        setModalVisible(true);
      }}
      size={45} color="#fff" >
      </Ionicons>
      : <TouchableHighlight
        style={styles.openButton}
        onPress={() => {
          setModalVisible(true);
        }}
      >
        <Text style={styles.textStyle}>{props.title}</Text>
      </TouchableHighlight> }
      
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    backgroundColor: "white",
  },
  modalView: {
    margin: 20,
    backgroundColor: "beige",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  openButton: {
    
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  textStyle: {
    color: "#0078ff",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
    fontStyle: "italic",
  },
  roundIcon:{
    alignSelf:"center",
    color : "#000" ,
    marginBottom : 17,
    borderRadius: 20,
    justifyContent: "center",
    flexDirection: "column"
}
});

export default Px;