import React, { useState ,useEffect} from 'react';
import { SafeAreaView , StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import ip from './ipInput.json';



export default function Logout(props) { 

    const logOutUser = async () => { 
       const data = await fetch('http://'+ ip.userIp +':3001/control-center/api/logout', {
         method: 'POST',
         headers: { 
           'Accept': 'application/json',
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + props.token
         },
       });
       if(data.status===200){
         const logoutData = await data.json();
         console.log(logoutData);
         console.log("Succesful logout");
         props.navigation.navigate('Login');
       }
       else{
         console.log("Error Code : " + data.status + "\nError Message : " + data.statusText);
       }
     }

    return(
    <View >
        <View style={styles.container}><Ionicons name="ios-exit" size={15} onPress={logOutUser} style={{textDecorationLine : "underline", fontSize : 15}}> Αποσύνδεση</Ionicons></View>
    </View>
    );
}

const styles = StyleSheet.create({
    container: {
      marginRight: 20,
    }
  });