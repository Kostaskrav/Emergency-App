import React, { useState, useEffect, useLayoutEffect } from 'react';
import { StyleSheet, View, Image, Text, ScrollView, Button, Alert ,RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Logout from './Logout';
import Px from './Px';
import ip from './ipInput.json';
import _ from 'lodash';



export default function Profile(props) {

    const [listOfIncidents, setListOfIncidents] = useState([]);
    const [liveIncident, setLiveIncident] = useState({});
    const [refreshing, setRefreshing] = React.useState(false);


    const readyIncidents = async () => {
        const data = await fetch('http://' + ip.userIp + ':3001/control-center/api/incidents', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + props.route.params.detail.token
            }
        });
        if (data.status === 200) {
            const incidentData = await data.json();
            const liveIncidents = [];
            const agencyUser = props.route.params.detail.agency;

            incidentData.forEach(incedent => {
                let userInIncident = false;
                if ((incedent.users).hasOwnProperty(agencyUser)) {
                    incedent.users[agencyUser].forEach(i => {
                        if (i._id === props.route.params.detail.id) {
                            userInIncident = true;
                        }
                    })
                }
                if (!incedent.isOpen && userInIncident) { //incident is closed && userid took part

                    liveIncidents.push(incedent);
                }
            });
            fetchReports(liveIncidents); //fetch the reports for each incident
        } else {
            console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
          }
    }

    const fetchReports = async (liveIncidents) => {
        const data = await fetch('http://' + ip.userIp + ':3001/control-center/api/reports', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + props.route.params.detail.token
            }
        });
        if (data.status === 200) {
            const reportData = await data.json();
            var liveIncidentsL = [...liveIncidents];

            await liveIncidents.map((incident, index) => {
                reportData.map((report) => {
                    if ((report.incidentId === incident._id) && (report.userId === props.route.params.detail.id)) {
                        //check if the rerpot has been modified 
                        if (!report.isOpen) {//it was modified 
                            //pop it from the liveincidents 
                            // console.log(liveIncidentsL)
                            liveIncidentsL.map((i, ind) => {
                                if (incident._id === i._id) {
                                    liveIncidentsL.splice(ind, 1);
                                }
                            });
                        }
                    }
                });
            });
            if(JSON.stringify(liveIncident) !== JSON.stringify(liveIncidentsL) ){
                setListOfIncidents([...liveIncidentsL]);
            }
        } else {
            console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
              }
    }

    const checkLiveIncident = async () => {
        const data = await fetch('http://' + ip.userIp + ':3001/control-center/api/incidents', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + props.route.params.detail.token
            }
        });
        if (data.status === 200) {
            const incidentData = await data.json();
            const liveIncidents = {};
            const agencyUser = props.route.params.detail.agency;
            
            incidentData.forEach(incedent => {
                let userInIncident = false;

                if ((incedent.users).hasOwnProperty(agencyUser)) {
                    incedent.users[agencyUser].forEach(i => {
                        if (i._id === props.route.params.detail.id) {
                            userInIncident = true;
                        }
                    })
                }

                if (incedent.isOpen && userInIncident) { //incident is OPEN("live") && userid took part
                    setLiveIncident(incedent);
                    
                }else if(!incedent.isOpen && userInIncident){
                    setLiveIncident({});
                }
            });

        } else {
            console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
               }
    }

    const customizeIncidents = () => {
        
        const customizedIncidents = [];
        listOfIncidents.map((item) => {
            customizedIncidents.push("[ID :" + item._id + "\nΤίτλος : " + item.title + "\nΗμερομηνία : " + item.startDate + "\nLat : " + item.x + "\nLon : " + item.y + "\nΤηλέφωνο : " + item.telephone + "]\n");
        });
        return customizedIncidents;
    }

    const customizeLiveIncidents = () => {
        return ("[ID :" + liveIncident._id + "\nΤίτλος : " + liveIncident.title + "\nΗμερομηνία : " + liveIncident.startDate + "\nLat : " + liveIncident.x + "\nLon : " + liveIncident.y + "\nΤηλέφωνο : " + liveIncident.telephone + "]\n");

    }

    const chooseGender = () => {
        if (props.route.params.detail.gender === "male")
            return "Άνδρας";
        else if (props.route.params.detail.gender === "female")
            return "Γυναίκα";
        else 
            return props.route.params.detail.gender;
    }

    const chooseForce = () => {
        if (props.route.params.detail.role === "policeman")
            return "Αστυνομικός";
        else if (props.route.params.detail.role === "firefighter")
            return "Πυροσβέτης";
        else if (props.route.params.detail.role === "navy")
            return "Λιμενικός";
        else if (props.route.params.detail.role === "ekab")
            return "ΕΚΑΒ";
        else
            return props.route.params.detail.role
    }

    const onRefresh = React.useCallback(async () => {
        setRefreshing(true);
            readyIncidents();
            checkLiveIncident(); //fetch the live incidents for the user 
        setRefreshing(false);
      }, [refreshing]);



    useEffect(() => {
            readyIncidents();
            checkLiveIncident(); //fetch the live incidents for the user
    }, []);

   
    

    

    useLayoutEffect(() => {
        props.navigation.setOptions({
            headerRight: () => (
                <Logout {...props} token={props.route.params.detail.token} />
            ),
        });
    }, []);

    return (

        <ScrollView showsVerticalScrollIndicator={false}
        refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }>

            <View style={styles.container}>
                <View style={styles.profileImage}>
                    <Image source={{ uri: 'https://img.icons8.com/ios/150/000000/user-male-circle.png' }} style={styles.image} resizeMode='center' />
                </View>
            </View>
            <View style={styles.infoContainer}>
                <Text style={styles.textName}>{props.route.params.detail.firstName} {props.route.params.detail.lastName}</Text>
                <Text style={styles.textAgency}>{chooseForce()}</Text>
                <Text style={styles.textGender}>{chooseGender()}</Text>
                <Text style={styles.textGender}>Email: {props.route.params.detail.email}</Text>
                <Text style={styles.textGender}>Τοποθεσία x:{props.route.params.detail.x}</Text>
                <Text style={styles.textGender}>Τοποθεσία y:{props.route.params.detail.y}</Text>
            </View>
            <View style={styles.buttonsContainer}>
                <Px title={"Λεπτομέριες για τα περιστατικά προς κατάθεση αναφοράς"} incidents={customizeIncidents()} choose={"incidents"} />
                <Px title={"Λεπτομέριες ενεργού περιστατικού"} incident={customizeLiveIncidents()} liveIncident={liveIncident} choose={"live"} />
            </View>
            <View style={styles.record}>
                <Text style={styles.recordNo} >{listOfIncidents.length}</Text>
                <Text style={styles.recordText} >ΠΕΡΙΣΤΑΤΙΚΑ ΠΡΟΣ ΚΑΤΑΘΕΣΗ ΑΝΑΦΟΡΑΣ</Text>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignSelf: 'center',
        backgroundColor: '#fff'
    },
    image: {
        flex: 1,
        width: undefined,
        height: undefined,
    },
    profileImage: {
        width: 200,
        height: 200,
        borderRadius: 100,
        marginVertical: 20
    },
    infoContainer: {
        alignSelf: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    textName: {
        fontSize: 27,
        fontWeight: '500',
        fontStyle: "italic",
        textDecorationLine : "underline"
    },
    textAgency: {
        fontSize: 20,
        color: 'grey'
    },
    textGender : {
        fontSize: 15,
        color : "grey",
        fontStyle: "italic",
    },
    buttonsContainer: {
        marginTop: 55,
        paddingHorizontal: 20,
        flexDirection: 'row',
        justifyContent: "space-between",
    },
    button: {
        width: 160,
        padding: 20,
        color: '#0078ff'
    },
    record: {
        marginTop: 30,
        alignSelf: 'center',
        borderTopWidth: 1,
        borderTopColor: 'grey',
        width: '80%'
    },
    recordNo: {
        color: 'grey',
        fontSize: 60,
        fontWeight: 'bold',
        alignSelf: 'center'
    },
    recordText: {
        color: 'grey',
        fontSize: 30,
        alignSelf: 'center',
        marginTop: -15
    }
});