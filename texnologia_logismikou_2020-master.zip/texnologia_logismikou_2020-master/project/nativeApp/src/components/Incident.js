import React, { useState ,useEffect} from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';
import { Icon } from 'react-native-elements';
import { Ionicons } from '@expo/vector-icons';
import Px from './Px';

export default function Incident(props) { 

    const do1 = () => {
        if(props.isHead){
            return(
                
                <View>
        <View style={{flexDirection : "column" , alignSelf : "center"}}>
        <Text style={styles.header}>ID: {props.item._id}</Text>
        {props.item.isOpen ? <Text style={{alignSelf : "center", padding : 3 , color : "white",backgroundColor:"red" ,fontWeight : "bold", fontSize : 15 ,fontStyle: 'italic'  }} >LIVE</Text> : null }

        </View>
                <View >
                <Px title={"Αναφορές"} item={props.item} reports={props.listOfReports} choose={"reports"} />

                </View>
                <View >
                    <Px title={"Επίσημη Αναφορά"} item={props.item} fr={props.fr} choose={"fr"} />
 
                </View>
                <View  >
                <Px  title={"Λεπτομέριες Περιστατικού"} item={props.item}  choose={"details"} />
                </View>
                <View style={{borderBottomWidth : 1}} >
                <Px  title={"Όργανα υπηρεσίας στο περιστατικό"} item={props.item} agencyId={props.agencyId}  choose={"users"} />
                </View>
                </View>
            );
        }
        return(
        <View style={{borderRadius: 10}}>
             <View style={{flexDirection : "column" , alignSelf : "center"}}>
                <Text style={styles.header}>ID: {props.item._id}</Text>
                <Text style={styles.subHeader}>Πατηστε το βελάκι για να δείτε τα στοιχέια του Περιστατικού</Text>

            </View>
            <Px title={"Λεπτομέριες Περιστατικού"} item={props.item}  coord={true} />     
        </View>
        );
    }

    return(
    <View style={styles.item}>
        <View style={styles.textWrap}>
       
        {props.isHead ? do1() : null}
    </View>
    {!props.isHead ? do1() : null}
    </View>
);}

const styles = StyleSheet.create({
    item: {
        alignSelf:"center",

        backgroundColor: '#fff',
        paddingHorizontal: 25,
        paddingVertical: 10,
        borderRadius: 10,
        marginHorizontal: 10,
        marginVertical: 5,
        flexDirection: "row",
        justifyContent: "space-between"
    },
    textWrap: {
        flexDirection: "row",
        justifyContent: "center",

        paddingHorizontal: 15
    },
    header: {
        fontSize: 15,
        fontWeight : "bold",
        fontStyle: 'italic',
        textDecorationLine: "underline",
        color: '#000',
    },
    subHeader: {
        fontSize: 11,
        fontStyle: 'italic',
        color: 'grey'
    },
    roundIcon:{
        alignSelf:"center",
        margin : 20,
        borderRadius: 20,
        justifyContent: "center",
        flexDirection: "column"
    }
  });
