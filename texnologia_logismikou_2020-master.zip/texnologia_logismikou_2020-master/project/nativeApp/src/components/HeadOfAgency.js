import React, { useState, useEffect, useLayoutEffect } from 'react';
import { StyleSheet, Text, View, SafeAreaView, FlatList ,RefreshControl} from 'react-native';
import { Icon } from 'react-native-elements';
import Incident from './Incident';
import Logout from './Logout';
import ip from './ipInput.json';
import _ from 'lodash';




export default function Coordinator(props) {
  const [listOfIncidents, setListOfIncidents] = useState([]);
  const [formalReport, setFormalReport] = useState({});
  const [listOfReports, setListOfReports] = useState([]);
  const [refreshing, setRefreshing] = React.useState(false);



  const fetchIncidents = async () => {
    const data = await fetch('http://' + ip.userIp + ':3001/control-center/api/incidents', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + props.route.params.detail.token
      }
    });
    if (data.status === 200) {

      const incidentData = await data.json();
      const liveIncidents = [];
      incidentData.forEach(incident => {
        liveIncidents.push(incident);
        if (!incident.isOpen) {
          fetchReports(); //fetch all the reports for the agency
          fetchFormalReport(); //get the formal report 
        }
      });
      if (JSON.stringify(listOfIncidents) !== JSON.stringify(liveIncidents)) {
        setListOfIncidents([...liveIncidents]);
      }


    } else {
      console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
       }
  }

  const fetchReports = async () => {
    const data = await fetch('http://' + ip.userIp + ':3001/control-center/api/reports', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + props.route.params.detail.token
      }
    });
    if (data.status === 200) {

      const reportsData = await data.json();
      const reports = [];
      reportsData.forEach(report => {
        if (report.agencyId === props.route.params.detail.agency) {
          reports.push(report);
        }
      });
      if (JSON.stringify(listOfReports) !== JSON.stringify(reports)) {
        setListOfReports([...reports]);
      }
    } else {
      console.log("Error Code : " + data.status + "\nError Message9 : " + data.statusText);
        }
  }

  const fetchFormalReport = async () => {
    const data = await fetch('http://' + ip.userIp + ':3001/control-center/api/formal-reports', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + props.route.params.detail.token
      }
    });
    if (data.status === 200) {

      const freportsData = await data.json();
      let fId = "";
      await freportsData.forEach(freport => {
        if (freport.agencyId === props.route.params.detail.agency) {
          fId = freport._id;
        }
      });
      if (fId !== "") {
        const data2 = await fetch('http://' + ip.userIp + ':3001/control-center/api/formal-reports/' + fId, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + props.route.params.detail.token
          }
        });
        if (data2.status === 200) {
          const freport2 = await data2.json();
            setFormalReport(freport2);

          
        }
        else {
          console.log("Error Code : " + data2.status + "\nError Message9 : " + data2.statusText);
        
        }
      }
    } else {
      //console.log("Not formal report submitted yet ! ");
    }
  }

  const onRefresh = React.useCallback(async () => {
    setRefreshing(true);
    fetchIncidents();
    setRefreshing(false);
  }, [refreshing]);

  useEffect(() => {
      fetchIncidents();
  }, []);

  useLayoutEffect(() => {
    props.navigation.setOptions({
      headerRight: () => (
        <Logout {...props} token={props.route.params.detail.token} />
      ),
    });
  }, []);


  return (

    <SafeAreaView style={styles.item}>
      <Text style={{...styles.recordText , textDecorationLine: 'underline' }} >ΑΡΙΘΜΟΣ ΠΕΡΙΣΤΑΤΙΚΩΝ : {listOfIncidents.length}</Text>

                
          
      {listOfIncidents.length > 0
        ? <FlatList
          data={listOfIncidents}
          renderItem={({ item }) => (<Incident agencyId={props.route.params.detail.agency} listOfReports={listOfReports} fr={formalReport} isHead={true} item={item} />)}
          keyExtractor={item => item._id}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
        /> : <Text style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 200 }}>Δεν υπάρχουν αναφόρες απο χρήστες</Text>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  item: {
    backgroundColor: '#fff',
    paddingHorizontal: 25,
    paddingVertical: 10,
    borderRadius: 10,
    marginHorizontal: 10,
    marginVertical: 5
  },
  header: {
    fontSize: 25,
    color: '#000'
  },
  subHeader: {
    fontSize: 15,
    fontStyle: 'italic',
    color: 'grey'
  },record: {
    marginTop: 30,
    alignSelf: 'center',
    
    borderTopColor: 'grey',
    width: '80%'
},

recordText: {
    color: 'black',
    fontSize: 25,
    alignSelf: 'center',
    fontWeight : "500"
    
   
}
});