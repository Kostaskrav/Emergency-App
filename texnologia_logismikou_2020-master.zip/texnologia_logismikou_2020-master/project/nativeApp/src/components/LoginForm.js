import React, { Component } from 'react';
import { Alert, Button, TextInput, View, StyleSheet,FlatList } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ip from './ipInput.json';

export default class Login extends Component {
  constructor(props) {
    super(props);
    
    this.state = {
      username: '',
      password: ''
    };
  }
  
  onLogin() {
    const { username, password } = this.state;
    this.fetchUser( username.toLowerCase() );
  }

  fetchUser = async (usern) => { 

    const data = await fetch('http://'+ ip.userIp +':3001/control-center/api/login', {
      method: 'POST',
      headers: { 
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        username : usern ,
        password : this.state.password
      })
    });
    if(data.status===200){

      const userData = await data.json();
      this.setState({
        username: '',
        password: ''
      });
      console.log(userData);
      if(userData.role==="coordinator"){
        this.props.navigation.navigate('Coordinator', {detail: userData  });
      }
      else if(userData.isHeadOfAgency){ // read all
        //for the head of agencies 
        this.props.navigation.navigate('HeadOfAgency', {detail: userData  });
      }
      else{ //for the users 
        
        this.props.navigation.navigate('Profile', {detail: userData  });

      }
    }
    else{
      this.setState({
        username: '',
        password: ''
      });
      alert("Τα στοιχεία που δώσατε δεν είναι σωστά, παρακαλώ δοκιμάστε ξανα");
      console.log("Error Code : " + data.status + "\nError Message : " + data.statusText);
    }
  }



  render() {
    return (
      <View style={styles.container}>
        <TextInput
          value={this.state.username}
          onChangeText={(username) => this.setState({ username })}
          placeholder={'Username'}
          style={styles.input}
        />
        <TextInput
          value={this.state.password}
          onChangeText={(password) => this.setState({ password })}
          placeholder={'Password'}
          secureTextEntry={true}
          style={styles.input}
        />
        
        <Button
          color = "#c9c943"
          title={'Σύνδεση'}
          onPress={this.onLogin.bind(this)}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'beige',
    },
    input: {
      width: 200,
      height: 44,
      padding: 10,
      borderWidth: 1,
      borderColor: 'grey',
      borderRadius: 30,
      backgroundColor: "#fff",
      borderWidth: 2,
      marginBottom: 10,
    },
    submit_button: {
      backgroundColor : "red",
      borderRadius: 20,
    }
  });



