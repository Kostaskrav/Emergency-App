import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, FlatList, SafeAreaView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Login from './src/components/LoginForm';
import Coordinator from './src/components/Coordinator';
import Profile from './src/components/Profile';
import HeadOfAgency from './src/components/HeadOfAgency';

const Stack = createStackNavigator();


export default function App() {

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Login" component={Login} options={{ title : "999 ΚΕΝΤΡΟ ΕΛΕΓΧΟΥ"}} />
        <Stack.Screen name="Coordinator" component={Coordinator} options={{ headerLeft: null , title : "Συντονιστής" }} />
        <Stack.Screen name="HeadOfAgency" component={HeadOfAgency} options={{ headerLeft: null , title : "Αρχηγός υπηρεσίας" }} />
        <Stack.Screen name="Profile" component={Profile} options={{ headerLeft: null , title : "Προφίλ" }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 30,
    backgroundColor: '#e9ebee',
    alignItems: 'stretch',
    justifyContent: 'center',
  },
});
